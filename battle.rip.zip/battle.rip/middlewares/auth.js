const authMiddleware = (req, res, next) => {

	if (!req.isUserAuthenticated) {
		res.redirect('/login?next=' + req.path);
		return;
	}

	next();

}

module.exports = authMiddleware;