const csrfMiddleware = (req, res, next) => {

	const passedCsrfToken = req.body._csrftoken || req.headers['x-csrftoken'];

	if (!passedCsrfToken || passedCsrfToken !== req.session.csrfToken) {
		res.status(400);
		res.throwError('Invalid csrf token.');
		return;
	}

	next();

}

module.exports = csrfMiddleware;