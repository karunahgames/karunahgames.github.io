const Thread = require('../models/Thread');

module.exports = (app) => {

	app.get('/', async (req, res) => {

		const featuredThreads = await Thread.find({ isFeatured: true }).sort({ createdAt: -1 });
		const slicedFeaturedThreads = featuredThreads.slice(0, 5);
		const formattedFeaturedThreads = await Promise.all(slicedFeaturedThreads.map((thread) => thread.format()));

		res.context.page = 'index';
		res.context.title = 'Home';

		res.context.threads = formattedFeaturedThreads;

		res.render('index');

	});

}