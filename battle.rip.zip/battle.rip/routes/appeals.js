const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const User = require('../models/User');
const Appeal = require('../models/Appeal');
const AppealReply = require('../models/AppealReply');

module.exports = (app) => {

	app.get('/appeals', async (req, res) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;

		const filters = {
			user: req.query.user ? req.query.user : null,
			status: req.query.status ? req.query.status : null,
			assigned: req.query.assigned ? req.query.assigned : null,
			creation: req.query.creation ? req.query.creation : '0',
			limit: req.query.limit ? req.query.limit : '15'
		};

		const appeals = await Appeal.find().sort({ createdAt: (filters.creation == 0 ? -1 : 1) });

		const filteredAppeals = [];
		for (const appeal of appeals) {

			if (appeal.isHidden) {
				continue;
			}

			if (filters.status && appeal.status != filters.status) {
				continue;
			}

			if (filters.assigned) {
				if (filters.assigned == 0 && appeal.type !== 'mute') {
					continue;
				} else if (filters.assigned == 1 && appeal.type !== 'ban') {
					continue;
				} else if (filters.assigned == 2 && appeal.type !== 'ipban') {
					continue;
				} else if (filters.assigned == 3 && appeal.type !== 'blacklist') {
					continue;
				}
			}

			const author = await User.findById(appeal.author);
			if (author && filters.user && (author.uuid != filters.user && author.name.toLowerCase() != filters.user.toLowerCase())) {
				continue;
			}

			filteredAppeals.push(appeal);

		}

		const q = `?user=${filters.user ?? ''}&status=${filters.status ?? ''}&assigned=${filters.assigned ?? ''}&creation=${filters.creation ?? ''}&limit=${filters.limit ?? ''}`;
		const appealsPagination = paginate(filteredAppeals, currentPage, filters.limit, `${q}&page={x}`);

		const formattedAppeals = [];
		for (const appeal of appealsPagination.items) {

			const replies = await AppealReply.find({ appeal: appeal.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;

			const formattedAppeal = await appeal.format();
			formattedAppeal.repliesCount = repliesCount;

			formattedAppeals.push(formattedAppeal);

		}

		res.context.page = 'appeals';
		res.context.title = 'Appeals';

		res.context.appeals = formattedAppeals;
		res.context.pagination = appealsPagination.nav;
		res.context.filters = filters;

		res.render('appeals');

	});

	app.get('/appeal/new', authMiddleware, async (req, res) => {

		res.context.page = 'appeals.new';
		res.context.title = 'New Appeal';

		res.render('appeal.new');

	});

	app.post('/appeal/new', csrfMiddleware, authMiddleware, async (req, res) => {

		const { type, answers } = req.body;

		if (!await req.validateInput({
			type: 'required',
			answers: 'required',
		})) { return };

		if (!['ban', 'ipban', 'blacklist', 'mute'].includes(type)) {
			req.flash('errorMessage', 'Incorrect appeal type.')
			return res.redirect(req.referer);
		}

		if ([answers.ign, answers.reason, answers.punisher, answers.justification, answers.proof, answers.extra].some((a) => !Boolean(a))) {
			req.flash('errorMessage', 'Make sure you\'ve entered all the answers.')
			return res.redirect(req.referer);
		}

		const appeal = await Appeal.create({
			type: type,
			author: req.authenticatedUser.id,
			answers: {
				ign: answers.ign,
				reason: answers.reason,
				punisher: answers.punisher,
				justification: answers.justification,
				proof: answers.proof,
				extra: answers.extra,
			}
		});

		req.flash('successMessage', 'The appeal has been successfully created.');
		res.redirect(`/appeal/${appeal.fid}`);

	});

	app.post('/appeal/reply', csrfMiddleware, authMiddleware, async (req, res) => {

		const appealId = req.body.appeal;
		const { content } = req.body;
		
		let appeal = null;
		try {
			appeal = await Appeal.findById(appealId);
		} catch (err) { }

		if (!appeal) {
			return res.redirect(req.referer);
		}

		if (appeal.author !== req.authenticatedUser.id) {
			return res.throw404();
		}

		if (appeal.status !== 0) {
			return res.redirect(req.referer);
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await AppealReply.create({
			author: req.authenticatedUser.id,
			appeal: appeal.id,
			content
		});

		await Appeal.findByIdAndUpdate(appeal.id);

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});
	
	app.get('/appeal/:id', async (req, res) => {

		const appealId = req.params.id;

		let appeal = null;
		try {
			appeal = await Appeal.findOne({ fid: appealId });
		} catch (err) { }

		if (!appeal) {
			return res.throw404();
		}

		const appealReplies = await AppealReply.find({ appeal: appeal.id }).sort({ createdAt: 1 });
		const formattedAppealReplies = [];

		for (const reply of appealReplies) {
			const formattedReply = await reply.format();
			formattedReply.isManageable = await reply.isManageableBy(req.authenticatedUser);
			formattedAppealReplies.push(formattedReply);
		}
		
		const formattedAppeal = await appeal.format();
		formattedAppeal.isManageable = await appeal.isManageableBy(req.authenticatedUser);
		formattedAppeal.replies = formattedAppealReplies;

		res.context.page = 'appeal';
		res.context.title = `Appeal #${appeal.fid}`;
		
		res.context.appeal = formattedAppeal;

		res.render('appeal');

	});

}