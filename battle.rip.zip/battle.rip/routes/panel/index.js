const Thread = require('../../models/Thread');
const ThreadReply = require('../../models/ThreadReply');
const ProfilePost = require('../../models/ProfilePost');
const Ticket = require('../../models/Ticket');
const User = require('../../models/User');

module.exports = (app) => {

	app.get('/panel', async (req, res) => {

		const stats = [];

		const threads = await Thread.find();
		stats.push({ name: 'Threads', value: threads.length });

		const threadReplies = await ThreadReply.find();
		stats.push({ name: 'Thread Replies', value: threadReplies.length });

		const profilePosts = await ProfilePost.find();
		stats.push({ name: 'Profile Posts', value: profilePosts.length });

		const tickets = await Ticket.find();
		stats.push({ name: 'Tickets', value: tickets.length });

		const users = await User.find();
		stats.push({ name: 'Users', value: users.length });

		res.context.page = 'panel.index';
		res.context.title = 'Dashboard';

		res.context.stats = stats;

		res.render('panel/index');

	});

}