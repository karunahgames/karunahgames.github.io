module.exports = async (app, req, res, next) => {

	if (!req.isUserAuthenticated) {
		return res.redirect('/');
	}

	if (!await req.authenticatedUser.isStaff()) {
		return res.redirect('/');
	}

	res.throwError = (error) => {

		res.context.page = 'error';
		res.context.title = 'Error';

		res.context.error = error;

		res.render('panel/error');

	}
	
	next();

}