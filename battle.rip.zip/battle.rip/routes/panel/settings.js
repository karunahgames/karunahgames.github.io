const Setting = require('../../models/Setting');

module.exports = (app) => {

	app.get('/panel/settings', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const settings = await Setting.getSettings();

		res.context.page = 'panel.settings';
		res.context.title = 'Settings';

		res.context.settings = settings;
		
		res.render('panel/settings');

	});

	app.post('/panel/settings', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const newSettings = req.body;

		for (const [key, value] of Object.entries(newSettings)) {
			await Setting.updateOne({ key }, { value }, {
				upsert: true,
				setDefaultsOnInsert: true
			});
		}

		res.redirect(req.referer);

	});

}
