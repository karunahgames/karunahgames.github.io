const csrfMiddleware = require('../../middlewares/csrf');
const Notification = require('../../models/Notification');
const Appeal = require('../../models/Appeal');
const AppealReply = require('../../models/AppealReply');

module.exports = (app) => {

	app.get('/panel/appeals', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		const searchQuery = req.query.search ? req.query.search : null;

		const appeals = await Appeal.find().sort({ createdAt: 1 });

		appeals.sort((a, b) => a.status === 1 ? -1 : 0);
		appeals.sort((a, b) => a.status === 2 ? -1 : 0);
		appeals.sort((a, b) => a.status === 0 ? -1 : 0);

		const filteredAppeals = [];
		for (const appeal of appeals) {

			if (searchQuery) {
				const regex = new RegExp(searchQuery, 'i');
				if (!regex.test(appeal.fid)) {
					continue;
				}
			}

			if (!await appeal.isManageableBy(req.authenticatedUser)) {
				continue;
			}

			filteredAppeals.push(appeal);

		}

		const appealsPagination = paginate(filteredAppeals, currentPage, 15, (searchQuery ? `?search=${searchQuery}&page={x}` : '?page={x}'));

		const formattedAppeals = [];
		for (const appeal of appealsPagination.items) {

			const replies = await AppealReply.find({ appeal: appeal.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;

			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedAppeal = await appeal.format();
			formattedAppeal.repliesCount = repliesCount;
			formattedAppeal.latestReply = formattedLatestReply;

			formattedAppeals.push(formattedAppeal);

		}

		res.context.page = 'panel.appeals';
		res.context.title = 'Appeals';

		res.context.appeals = formattedAppeals;
		res.context.searchQuery = searchQuery;
		res.context.pagination = appealsPagination.nav;
		
		res.render('panel/appeals');

	});

	app.post('/panel/appeal/accept', csrfMiddleware, async (req, res) => {

		const appealId = req.body.appeal;
		
		let appeal = null;
		try {
			appeal = await Appeal.findById(appealId);
		} catch (err) { }

		if (!appeal) {
			return res.redirect(req.referer);
		}

		if (appeal.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await appeal.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Appeal.findByIdAndUpdate(appeal.id, {
			status: 1
		});

		if (appeal.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: appeal.author,
				title: 'Appeal Accepted',
				content: `Your appeal #${appeal.fid} has been accepted.`,
				link: `/appeal/${appeal.fid}`
			});
		}

		req.flash('successMessage', 'The appeal has been successfully accepted.');
		res.redirect(req.referer);

	});

	app.post('/panel/appeal/reject', csrfMiddleware, async (req, res) => {

		const appealId = req.body.appeal;
		
		let appeal = null;
		try {
			appeal = await Appeal.findById(appealId);
		} catch (err) { }

		if (!appeal) {
			return res.redirect(req.referer);
		}

		if (appeal.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await appeal.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Appeal.findByIdAndUpdate(appeal.id, {
			status: 2
		});

		if (appeal.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: appeal.author,
				title: 'Appeal Rejected',
				content: `Your appeal #${appeal.fid} has been rejected.`,
				link: `/appeal/${appeal.fid}`
			});
		}

		req.flash('successMessage', 'The appeal has been successfully rejected.');
		res.redirect(req.referer);

	});

	app.post('/panel/appeal/hide', csrfMiddleware, async (req, res) => {

		const appealId = req.body.appeal;
		
		let appeal = null;
		try {
			appeal = await Appeal.findById(appealId);
		} catch (err) { }

		if (!appeal) {
			return res.redirect(req.referer);
		}

		if (!await appeal.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Appeal.findByIdAndUpdate(appeal.id, { isHidden: !appeal.isHidden });

		if (appeal.isHidden) {
			req.flash('successMessage', 'The appeal has been successfully unhidden.');
		} else {
			req.flash('successMessage', 'The appeal has been successfully hidden.');
		}

		res.redirect(req.referer);

	});


	app.post('/panel/appeal/reply', csrfMiddleware, async (req, res) => {

		const appealId = req.body.appeal;
		const { content } = req.body;
		
		let appeal = null;
		try {
			appeal = await Appeal.findById(appealId);
		} catch (err) { }

		if (!appeal) {
			return res.redirect(req.referer);
		}

		if (!await appeal.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await AppealReply.create({
			author: req.authenticatedUser.id,
			appeal: appeal.id,
			content
		});

		await Appeal.findByIdAndUpdate(appeal.id);

		if (appeal.author !== req.authenticatedUser.id) {
			Notification.create({
				user: appeal.author,
				title: 'Appeal Reply',
				content: `${req.authenticatedUser.name} has replied to your appeal #${appeal.fid}.`,
				link: `/appeal/${appeal.fid}`
			});
		}

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});

	app.get('/panel/appeal/:id', async (req, res) => {

		const appealId = req.params.id;

		let appeal = null;
		try {
			appeal = await Appeal.findOne({ fid: appealId });
		} catch (err) { }

		if (!appeal) {
			return res.throw404();
		}

		if (!await appeal.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		const appealReplies = await AppealReply.find({ appeal: appeal.id }).sort({ createdAt: 1 });
		const formattedAppealReplies = [];

		for (const reply of appealReplies) {
			const formattedReply = await reply.format();
			formattedAppealReplies.push(formattedReply);
		}
		
		const formattedAppeal = await appeal.format();
		formattedAppeal.replies = formattedAppealReplies;

		res.context.page = 'panel.appeal';
		res.context.title = `Appeal #${appeal.fid}`;
		
		res.context.appeal = formattedAppeal;

		res.render('panel/appeal');

	});

}