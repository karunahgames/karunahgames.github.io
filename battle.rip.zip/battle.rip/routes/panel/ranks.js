const csrfMiddleware = require('../../middlewares/csrf');
const Rank = require('../../models/Rank');
const getRanks = require('../../utils/getRanks');

module.exports = (app) => {

	app.get('/panel/ranks', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const ranks = await Rank.find().sort({ order: 1 });
		const formattedRanks = await Promise.all(ranks.map((rank) => rank.format()));

		res.context.page = 'panel.ranks';
		res.context.title = 'Ranks';

		res.context.ranks = formattedRanks;

		res.render('panel/ranks');

	});

	app.post('/panel/ranks/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const rankId = req.body.rank;
		const { title, color, order, isDonator, isMedia, isStaff, isModeration, isAdministration } = req.body;

		const rank = await Rank.findById(rankId);
		if (!rank) {
			return res.redirect(req.referer);
		}

		await Rank.findByIdAndUpdate(rank.id, {
			title,
			color,
			order,
			isDonator: Boolean(isDonator),
			isMedia: Boolean(isMedia),
			isStaff: Boolean(isStaff),
			isModeration: Boolean(isModeration),
			isAdministration: Boolean(isAdministration)
		});

		res.redirect(req.referer);

	});

	app.post('/panel/ranks/sync', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const ranksData = await getRanks();

		if (ranksData && ranksData.length > 0) {
			for (const rank of ranksData) {
				const _rank = await Rank.findOne({ name: rank.name });
				if (!_rank) {
					await Rank.create({
						uuid: rank.uuid,
						name: rank.name,
						title: rank.name.capitalize()
					});
				}
			}
		}

		const ranks = await Rank.find();

		if (ranks.length > 0) {
			for (const rank of ranks) {
				const _ranks = await getRanks(rank.name);
				if (!_ranks || _ranks.length == 0) {
					await Rank.deleteOne({ name: rank.name });
				}
			}
		}

		res.redirect(req.referer);

	});

}
