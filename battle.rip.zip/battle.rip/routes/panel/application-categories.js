const csrfMiddleware = require('../../middlewares/csrf');
const Rank = require('../../models/Rank');
const ApplicationCategory = require('../../models/ApplicationCategory');

module.exports = (app) => {

	app.get('/panel/application-categories', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const applicationCategories = await ApplicationCategory.find().sort({ order: 1 });
		const formattedApplicationCategories = await Promise.all(applicationCategories.map((category) => category.format()));

		const ranks = await Rank.find().sort({ order: 1 });
		const formattedRanks = await Promise.all(ranks.map((rank) => rank.format()));

		res.context.page = 'panel.applicationCategories';
		res.context.title = 'Application Categories';

		res.context.applicationCategories = formattedApplicationCategories;
		res.context.ranks = formattedRanks;
		
		res.render('panel/application-categories');

	});

	app.post('/panel/application-categories/create', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const { name, description, slug, order, questions, moderationRanks } = req.body;

		await ApplicationCategory.create({
			name,
			description,
			slug,
			order: order ? parseInt(order) : '5',
			moderationRanks: moderationRanks || [],
			questions
		});

		req.flash('successMessage', 'Application category has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/panel/application-categories/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;
		const { name, description, slug, order, questions, moderationRanks } = req.body;

		const applicationCategory = await ApplicationCategory.findById(categoryId);
		if (!applicationCategory) {
			return res.redirect(req.referer);
		}

		await ApplicationCategory.findByIdAndUpdate(applicationCategory.id, {
			name,
			description,
			slug,
			order: order ? parseInt(order) : '5',
			moderationRanks: moderationRanks || [],
			questions
		});

		req.flash('successMessage', 'Application category has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/panel/application-categories/delete', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;

		const applicationCategory = await ApplicationCategory.findById(categoryId);
		if (!applicationCategory) {
			return res.redirect(req.referer);
		}

		await ApplicationCategory.findByIdAndDelete(applicationCategory.id);

		req.flash('successMessage', 'Application category has been successfully deleted.');
		res.redirect(req.referer);

	});

}
