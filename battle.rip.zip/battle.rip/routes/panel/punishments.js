const csrfMiddleware = require('../../middlewares/csrf');
const PunishmentComment = require('../../models/PunishmentComment');
const formatPunishment = require('../../utils/formatPunishment');
const getPunishment = require('../../utils/getPunishment');
const getPunishments = require('../../utils/getPunishments');

module.exports = (app) => {

	app.get('/panel/punishments', async (req, res) => {

		const punishments = await getPunishments();
		const formattedPunishments = await Promise.all(punishments.map((punishment) => formatPunishment(punishment)));

		res.context.page = 'panel.punishments';
		res.context.title = 'Punishments';

		res.context.punishments = formattedPunishments;
		
		res.render('panel/punishments');

	});

	app.post('/panel/punishment/comment', csrfMiddleware, async (req, res) => {

		// if (!await req.authenticatedUser.hasAdminPermission()) {
		// 	return res.redirect(req.referer);
		// }

		const punishmentId = req.body.punishment;
		const { content } = req.body;

		const punishment = await getPunishment(punishmentId);
		if (!punishment) {
			return res.redirect(req.referer);
		}

		await PunishmentComment.create({
			content: content,
			punishment: punishment.id,
			author: req.authenticatedUser.id
		});

		req.flash('successMessage', 'Comment has been successfully created.');
		res.redirect(req.referer);

	});

	app.get('/panel/punishment/:id', async (req, res) => {

		const punishmentId = req.params.id;

		const punishment = await getPunishment(punishmentId);
		if (!punishment) {
			return res.throw404();
		}

		const punishmentComments = await PunishmentComment.find({ punishment: punishment.id });
		const formattedPunishmentComments = await Promise.all(punishmentComments.map((comment) => comment.format()));

		const formattedPunishment = await formatPunishment(punishment);
		formattedPunishment.comments = formattedPunishmentComments;

		res.context.page = 'panel.punishment';
		res.context.title = 'Punishment';

		res.context.punishment = formattedPunishment;
		
		res.render('panel/punishment');

	});

}
