const paginate = require('../../utils/paginate');
const getPlayers = require('../../utils/getPlayers');
const getPlayerInfo = require('../../utils/getPlayerInfo');
const formatPlayer = require('../../utils/formatPlayer');
const User = require('../../models/User');
const getPlayerPunishments = require('../../utils/getPlayerPunishments');
const formatPunishment = require('../../utils/formatPunishment');

module.exports = (app) => {

	app.get('/panel/players', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasModPermission()) {
			return res.redirect(req.referer);
		}

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		const searchQuery = req.query.search ? req.query.search : null;

		const players = await getPlayers();
		
		const filteredPlayers = [];
		for (const player of players) {

			if (searchQuery) {
				const regex = new RegExp(searchQuery, 'i');
				if (!regex.test(player.uuid)) {
					const playerInfo = await getPlayerInfo(searchQuery);
					if (player.uuid !== playerInfo?.uuid) {
						continue;
					}
				}
			}

			filteredPlayers.push(player);

		}

		const playersPagination = paginate(filteredPlayers, currentPage, 15, (searchQuery ? `?search=${searchQuery}&page={x}` : '?page={x}'));

		const formattedPlayers = await Promise.all(playersPagination.items.map((player) => formatPlayer(player)));

		res.context.page = 'panel.players';
		res.context.title = 'Players';

		res.context.players = formattedPlayers;
		res.context.pagination = playersPagination.nav;
		res.context.searchQuery = searchQuery;
		
		res.render('panel/players');

	});

	app.get('/panel/player/:username', async (req, res) => {

		const { username } = req.params;

		const playerInfo = await getPlayerInfo(username);
		if (!playerInfo) {
			return res.throw404();
		}

		const player = await getPlayer(playerInfo.uuid);
		if (!player) {
			return res.throw404();
		}

		const user = await User.findOne({ uuid: playerInfo.uuid });
		// const formattedUser = await user?.format();
		
		const isBanned = false;
		const isOnline = false;
		const firstJoinedAt = player.firstJoin;
		const lastSeenAt = player.lastSeen;
		const lastServer = null;

		const formattedPlayer = await formatPlayer(player);
		formattedPlayer.isRegistered = Boolean(user);
		formattedPlayer.isBanned = isBanned;
		formattedPlayer.isOnline = isOnline;
		formattedPlayer.firstJoinedAt = formatTime(firstJoinedAt);
		formattedPlayer.lastSeenAt = formatTime(lastSeenAt);
		formattedPlayer.lastServer = lastServer;

		const playerPunishments = await getPlayerPunishments(playerInfo.uuid);
		const formattedPlayerPunishments = await Promise.all(playerPunishments.map((punishment) => formatPunishment(punishment)));

		formattedPlayer.punishments = formattedPlayerPunishments;

		res.context.page = 'panel.player';
		res.context.title = 'Player';

		res.context.player = formattedPlayer;
		
		res.render('panel/player');

	});

}
