const csrfMiddleware = require('../../middlewares/csrf');
const Rank = require('../../models/Rank');
const Wiki = require('../../models/Wiki');
const WikiPost = require('../../models/WikiPost');

module.exports = (app) => {

	app.get('/panel/wiki', async (req, res) => {

		const wikis = await Wiki.find().sort({ order: 1 });
		const formattedWikis = [];

		for (const wiki of wikis) {

			if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasAnyRank(wiki.accessRanks)) {
				continue;
			}

			const formattedWiki = await wiki.format();
			formattedWikis.push(formattedWiki);

		}

		const ranks = await Rank.find().sort({ order: 1 });
		const formattedRanks = await Promise.all(ranks.map((rank) => rank.format()));

		res.context.page = 'panel.wiki';
		res.context.title = 'Wiki';

		res.context.wikis = formattedWikis;
		res.context.ranks = formattedRanks;
		
		res.render('panel/wiki');

	});

	app.post('/panel/wiki/create', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const { title, content, slug, order, accessRanks } = req.body;

		await Wiki.create({
			title,
			content,
			author: req.authenticatedUser.id,
			slug,
			order: order ? parseInt(order) : '5',
			accessRanks: accessRanks || []
		});

		req.flash('successMessage', 'Wiki has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/panel/wiki/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const wikiId = req.body.wiki;
		const { title, content, slug, order, accessRanks } = req.body;

		const wiki = await Wiki.findById(wikiId);
		if (!wiki) {
			return res.redirect(req.referer);
		}

		if (!await wiki.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Wiki.findByIdAndUpdate(wiki.id, {
			title,
			content,
			slug,
			order: order ? parseInt(order) : '5',
			accessRanks: accessRanks || []
		});

		req.flash('successMessage', 'Wiki has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/panel/wiki/delete', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const wikiId = req.body.wiki;

		const wiki = await Wiki.findById(wikiId);
		if (!wiki) {
			return res.redirect(req.referer);
		}

		if (!await wiki.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Wiki.findByIdAndDelete(wiki.id);

		req.flash('successMessage', 'Wiki has been successfully deleted.');
		res.redirect('/panel/wiki');

	});

	app.post('/panel/wiki/post/create', csrfMiddleware, async (req, res) => {

		const wikiId = req.body.wiki;
		const { title, content } = req.body;

		let wiki = null;
		try {
			wiki = await Wiki.findById(wikiId);
		} catch (err) { }

		if (!wiki) {
			return res.redirect(req.referer);
		}

		if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasAnyRank(wiki.accessRanks)) {
			return res.redirect(req.referer);
		}

		await WikiPost.create({
			title,
			content,
			author: req.authenticatedUser.id,
			wiki: wiki.id
		});

		req.flash('successMessage', 'Wiki post has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/panel/wiki/post/edit', csrfMiddleware, async (req, res) => {

		const postId = req.body.post;
		const { title, content } = req.body;

		let post = null;
		try {
			post = await WikiPost.findById(postId);
		} catch (err) { }

		if (!post) {
			return res.redirect(req.referer);
		}

		let wiki = null;
		try {
			wiki = await Wiki.findById(post.wiki);
		} catch (err) { }

		if (!wiki) {
			return res.redirect(req.referer);
		}

		if (!await post.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await WikiPost.findByIdAndUpdate(post.id, {
			title,
			content,
		});

		req.flash('successMessage', 'Wiki post has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/panel/wiki/post/delete', csrfMiddleware, async (req, res) => {

		const postId = req.body.post;

		let post = null;
		try {
			post = await WikiPost.findById(postId);
		} catch (err) { }

		if (!post) {
			return res.redirect(req.referer);
		}

		let wiki = null;
		try {
			wiki = await Wiki.findById(post.wiki);
		} catch (err) { }

		if (!wiki) {
			return res.redirect(req.referer);
		}

		if (!await post.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await WikiPost.findByIdAndDelete(post.id);

		req.flash('successMessage', 'Wiki post has been successfully deleted.');
		res.redirect(req.referer);

	});

	app.get('/panel/wiki/:slug', async (req, res) => {

		const wikiSlug = req.params.slug;

		const wiki = await Wiki.findOne({ slug: wikiSlug });
		if (!wiki) {
			return res.throw404();
		}

		if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasAnyRank(wiki.accessRanks)) {
			return res.redirect(req.referer);
		}

		const wikiPosts = await WikiPost.find({ wiki: wiki.id });
		const formattedWikiPosts = [];

		for (const wikiPost of wikiPosts) {

			const formattedWikiPost = await wikiPost.format();
			formattedWikiPost.isManageable = await wikiPost.isManageableBy(req.authenticatedUser);

			formattedWikiPosts.push(formattedWikiPost);

		}

		const formattedWiki = await wiki.format();
		formattedWiki.posts = formattedWikiPosts;
		formattedWiki.isManageable = await wiki.isManageableBy(req.authenticatedUser);

		const wikis = await Wiki.find().sort({ order: 1, createdAt: 1 });
		const formattedWikis = await Promise.all(wikis.map((wiki) => wiki.format()));

		const ranks = await Rank.find().sort({ order: 1 });
		const formattedRanks = await Promise.all(ranks.map((rank) => rank.format()));

		res.context.page = 'wiki';
		res.context.title = 'Wiki';

		res.context.wiki = formattedWiki;
		res.context.wikis = formattedWikis;
		res.context.ranks = formattedRanks;

		res.render('panel/wiki.view');

	});

}
