const csrfMiddleware = require('../../middlewares/csrf');
const Rank = require('../../models/Rank');
const TicketCategory = require('../../models/TicketCategory');

module.exports = (app) => {

	app.get('/panel/ticket-categories', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const ticketCategories = await TicketCategory.find().sort({ order: 1 });
		const formattedTicketCategories = await Promise.all(ticketCategories.map((category) => category.format()));

		const ranks = await Rank.find().sort({ order: 1 });
		const formattedRanks = await Promise.all(ranks.map((rank) => rank.format()));

		res.context.page = 'panel.ticketCategories';
		res.context.title = 'Ticket Categories';

		res.context.ticketCategories = formattedTicketCategories;
		res.context.ranks = formattedRanks;
		
		res.render('panel/ticket-categories');

	});

	app.post('/panel/ticket-categories/create', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const { name, description, slug, order, moderationRanks } = req.body;

		await TicketCategory.create({
			name,
			description,
			slug,
			order: order ? parseInt(order) : '5',
			moderationRanks: moderationRanks || []
		});

		req.flash('successMessage', 'Ticket category has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/panel/ticket-categories/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;
		const { name, description, slug, order, moderationRanks } = req.body;

		const ticketCategory = await TicketCategory.findById(categoryId);
		if (!ticketCategory) {
			return res.redirect(req.referer);
		}

		await TicketCategory.findByIdAndUpdate(ticketCategory.id, {
			name,
			description,
			slug,
			order: order ? parseInt(order) : '5',
			moderationRanks: moderationRanks || []
		});

		req.flash('successMessage', 'Ticket category has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/panel/ticket-categories/delete', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;

		const ticketCategory = await TicketCategory.findById(categoryId);
		if (!ticketCategory) {
			return res.redirect(req.referer);
		}

		await TicketCategory.findByIdAndDelete(ticketCategory.id);

		req.flash('successMessage', 'Ticket category has been successfully deleted.');
		res.redirect(req.referer);

	});

}
