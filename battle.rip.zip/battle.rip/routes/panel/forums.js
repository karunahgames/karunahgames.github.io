const csrfMiddleware = require('../../middlewares/csrf');
const Forum = require('../../models/Forum');
const ForumCategory = require('../../models/ForumCategory');
const slugify = require('../../utils/slugify');

module.exports = (app) => {

	app.get('/panel/forums', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const forums = await Forum.find().sort({ order: 1 });
		const forumCategories = await ForumCategory.find().sort({ order: 1 });

		const formattedForumCategories = [];
		for (const forumCategory of forumCategories) {

			const filteredForums = forums.filter((forum) => forum.category === forumCategory.id);
			const formattedFilteredForums = await Promise.all(filteredForums.map((forum) => forum.format()));

			const formattedForumCategory = await forumCategory.format();
			formattedForumCategory.forums = formattedFilteredForums;

			formattedForumCategories.push(formattedForumCategory);

		}

		const formattedForums = await Promise.all(forums.map((forum) => forum.format()));

		res.context.page = 'panel.forums';
		res.context.title = 'Forums';

		res.context.forums = formattedForums;
		res.context.forumCategories = formattedForumCategories;
		
		res.render('panel/forums');

	});

	app.post('/panel/forums/create', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const { name, description, order, category, redirectUrl, isRestricted } = req.body;

		await Forum.create({
			name,
			description,
			slug: slugify(name),
			order: order ? parseInt(order) : '5',
			category,
			redirectUrl,
			isRestricted: Boolean(isRestricted)
		});

		res.redirect(req.referer);

	});

	app.post('/panel/forums/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const forumId = req.body.forum;
		const { name, description, order, category, redirectUrl, isRestricted } = req.body;

		const forum = await Forum.findById(forumId);
		if (!forum) {
			return res.redirect(req.referer);
		}

		await Forum.findByIdAndUpdate(forum.id, {
			name,
			description,
			slug: slugify(name),
			order: order ? parseInt(order) : 5,
			category,
			redirectUrl,
			isRestricted: Boolean(isRestricted)
		});

		res.redirect(req.referer);

	});

	app.post('/panel/forums/delete', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const forumId = req.body.forum;

		const forum = await Forum.findById(forumId);
		if (!forum) {
			return res.redirect(req.referer);
		}

		await Forum.findByIdAndDelete(forum.id);

		res.redirect(req.referer);

	});

	app.post('/panel/forums/category/create', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const { name, order } = req.body;

		await ForumCategory.create({
			name,
			order: order ? parseInt(order) : '5'
		});

		res.redirect(req.referer);

	});

	app.post('/panel/forums/category/edit', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;
		const { name, order } = req.body;

		const forumCategory = await ForumCategory.findById(categoryId);
		if (!forumCategory) {
			return res.redirect(req.referer);
		}

		await ForumCategory.findByIdAndUpdate(forumCategory.id, {
			name,
			order: order ? parseInt(order) : '5'
		});

		res.redirect(req.referer);

	});

	app.post('/panel/forums/category/delete', csrfMiddleware, async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		const categoryId = req.body.category;

		const forumCategory = await ForumCategory.findById(categoryId);
		if (!forumCategory) {
			return res.redirect(req.referer);
		}

		await ForumCategory.findByIdAndDelete(forumCategory.id);

		res.redirect(req.referer);

	});

}
