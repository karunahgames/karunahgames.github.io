const csrfMiddleware = require('../../middlewares/csrf');
const Notification = require('../../models/Notification');
const Ticket = require('../../models/Ticket');
const TicketReply = require('../../models/TicketReply');

module.exports = (app) => {

	app.get('/panel/tickets', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasModPermission()) {
			return res.redirect(req.referer);
		}

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		const searchQuery = req.query.search ? req.query.search : null;

		const tickets = await Ticket.find().sort({ createdAt: 1 });

		tickets.sort((a, b) => a.status === 1 ? -1 : 0);
		tickets.sort((a, b) => a.status === 2 ? -1 : 0);
		tickets.sort((a, b) => a.status === 0 ? -1 : 0);

		const filteredTickets = [];
		for (const ticket of tickets) {

			if (searchQuery) {
				const regex = new RegExp(searchQuery, 'i');
				if (!regex.test(ticket.fid)) {
					continue;
				}
			}

			if (!await ticket.isManageableBy(req.authenticatedUser)) {
				continue;
			}

			filteredTickets.push(ticket);

		}

		const ticketsPagination = paginate(filteredTickets, currentPage, 15, (searchQuery ? `?search=${searchQuery}&page={x}` : '?page={x}'));

		const formattedTickets = [];
		for (const ticket of ticketsPagination.items) {

			const replies = await TicketReply.find({ ticket: ticket.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;

			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedTicket = await ticket.format();
			formattedTicket.repliesCount = repliesCount;
			formattedTicket.latestReply = formattedLatestReply;

			formattedTickets.push(formattedTicket);

		}

		res.context.page = 'panel.tickets';
		res.context.title = 'Tickets';

		res.context.tickets = formattedTickets;
		res.context.searchQuery = searchQuery;
		res.context.pagination = ticketsPagination.nav;
		
		res.render('panel/tickets');

	});

	app.post('/panel/ticket/resolve', csrfMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (ticket.status === 1) {
			return res.redirect(req.referer);
		}

		if (!await ticket.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 1
		});

		if (ticket.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: ticket.author,
				title: 'Ticket Resolved',
				content: `Your ticket #${ticket.fid} has been resolved.`,
				link: `/ticket/${ticket.fid}`
			});
		}

		req.flash('successMessage', 'The ticket has been successfully resolved.');
		res.redirect(req.referer);

	});

	app.post('/panel/ticket/close', csrfMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (ticket.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await ticket.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 2
		});

		if (ticket.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: ticket.author,
				title: 'Ticket Closed',
				content: `Your ticket #${ticket.fid} has been closed.`,
				link: `/ticket/${ticket.fid}`
			});
		}

		req.flash('successMessage', 'The ticket has been successfully closed.');
		res.redirect(req.referer);

	});

	app.post('/panel/ticket/open', csrfMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (ticket.status === 0) {
			return res.redirect(req.referer);
		}

		if (!await ticket.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 0
		});

		req.flash('successMessage', 'The ticket has been successfully opened.');
		res.redirect(req.referer);

	});

	app.post('/panel/ticket/reply', csrfMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		const { content } = req.body;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (!await ticket.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await TicketReply.create({
			author: req.authenticatedUser.id,
			ticket: ticket.id,
			content
		});

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 0
		});

		if (ticket.author !== req.authenticatedUser.id) {
			Notification.create({
				user: ticket.author,
				title: 'Ticket Reply',
				content: `${req.authenticatedUser.name} has replied to your ticket #${ticket.fid}.`,
				link: `/ticket/${ticket.fid}`
			});
		}

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});

	app.get('/panel/ticket/:id', async (req, res) => {

		const ticketId = req.params.id;

		let ticket = null;
		try {
			ticket = await Ticket.findOne({ fid: ticketId });
		} catch (err) { }

		if (!ticket) {
			return res.throw404();
		}

		if (!await ticket.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		const ticketReplies = await TicketReply.find({ ticket: ticket.id }).sort({ createdAt: 1 });
		const formattedTicketReplies = [];

		for (const reply of ticketReplies) {
			const formattedReply = await reply.format();
			formattedTicketReplies.push(formattedReply);
		}
		

		const formattedTicket = await ticket.format();
		formattedTicket.replies = formattedTicketReplies;

		res.context.page = 'panel.ticket';
		res.context.title = `Ticket #${ticket.fid}`;
		
		res.context.ticket = formattedTicket;

		res.render('panel/ticket');

	});

}