const csrfMiddleware = require('../../middlewares/csrf');
const UhcGame = require('../../models/UhcGame');

module.exports = (app) => {

	app.get('/panel/uhc', async (req, res) => {

		const games = await UhcGame.find().sort({ createdAt: 1 });

		games.sort((a, b) => a.status === 1 ? -1 : 0);
		games.sort((a, b) => a.status === 2 ? -1 : 0);
		games.sort((a, b) => a.status === 0 ? -1 : 0);

		const formattedPendingGames = [];
		const formattedScheduledGames = [];
		const formattedPastGames = [];
		
		for (const game of games) {

			const formattedGame = await game.format();
			formattedGame.isManageable = await game.isManageableBy(req.authenticatedUser);

			const curentTime = new Date();
			const openingAt = new Date(game.openingAt);

			if (curentTime > openingAt) {
				formattedPastGames.push(formattedGame);
			} else if (game.status === 1) {
				formattedScheduledGames.push(formattedGame);
			} else if (game.status === 0) {
				formattedPendingGames.push(formattedGame);
			}

		}

		res.context.page = 'panel.uhc';
		res.context.title = 'UHC Management';
		res.context.pendingGames = formattedPendingGames;
		res.context.scheduledGames = formattedScheduledGames;
		res.context.pastGames = formattedPastGames;
		res.render('panel/uhc');

	});

	app.post('/panel/uhc/create', csrfMiddleware, async (req, res) => {

		const { server, mode, scenarios, options, potions, timings, openingAt } = req.body;

		await UhcGame.create({
			server : server ?? 'eu-uhc-01',
			mode: mode ?? 'ffa',
			host: req.authenticatedUser.id,
			scenarios: scenarios ?? '',
			options: {
				borderSize: parseInt(options?.borderSize) ?? 2000,
				dynamicBorder: Boolean(options?.dynamicBorder),
				nether: Boolean(options?.nether),
				bedBombing: Boolean(options?.bedBombing),
				noCleanPlus: Boolean(options?.noCleanPlus),
				safeLoot: Boolean(options?.safeLoot),
				autoAssign: Boolean(options?.autoAssign),
				shears: Boolean(options?.shears)
			},
			potions: {
				speed1: Boolean(potions?.speed1),
				speed2: Boolean(potions?.speed2),
				strength1: Boolean(potions?.strength1),
				strength2: Boolean(potions?.strength2),
				poison: Boolean(potions?.poison),
			},
			timings: {
				finalHeal: parseInt(timings?.finalHeal) ?? 10,
				gracePeriod: parseInt(timings?.gracePeriod) ?? 20,
				borderTime: parseInt(timings?.borderTime) ?? 45,
			},
			openingAt: new Date(openingAt)
		});

		req.flash('successMessage', 'The game has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/panel/uhc/accept', csrfMiddleware, async (req, res) => {

		const gameId = req.body.game;
		
		let game = null;
		try {
			game = await UhcGame.findById(gameId);
		} catch (err) { }

		if (!game) {
			return res.redirect(req.referer);
		}

		if (game.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await game.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await UhcGame.findByIdAndUpdate(game.id, {
			status: 1
		});

		if (game.host !== req.authenticatedUser.id) { 
			Notification.create({
				user: game.host,
				title: 'UHC Game Accepted',
				content: `Your uhc game #${game.fid} has been accepted.`,
				link: `/games`
			});
		}

		req.flash('successMessage', 'The game has been successfully accepted.');
		res.redirect(req.referer);

	});

	app.post('/panel/uhc/reject', csrfMiddleware, async (req, res) => {

		const gameId = req.body.game;
		
		let game = null;
		try {
			game = await UhcGame.findById(gameId);
		} catch (err) { }

		if (!game) {
			return res.redirect(req.referer);
		}

		if (game.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await game.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await UhcGame.findByIdAndUpdate(game.id, {
			status: 2
		});

		if (game.host !== req.authenticatedUser.id) { 
			Notification.create({
				user: game.host,
				title: 'UHC Game Rejected',
				content: `Your uhc game #${game.fid} has been rejected.`,
				link: `/games`
			});
		}

		req.flash('successMessage', 'The game has been successfully rejected.');
		res.redirect(req.referer);

	});

	app.post('/panel/uhc/delete', csrfMiddleware, async (req, res) => {

		const gameId = req.body.game;
		
		let game = null;
		try {
			game = await UhcGame.findById(gameId);
		} catch (err) { }

		if (!game) {
			return res.redirect(req.referer);
		}

		if (game.status === 0) {
			return res.redirect(req.referer);
		}

		if (!await game.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await UhcGame.findByIdAndDelete(game.id);

		req.flash('successMessage', 'The game has been successfully deleted.');
		res.redirect(req.referer);

	});

}