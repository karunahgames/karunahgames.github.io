const csrfMiddleware = require('../../middlewares/csrf');
const Notification = require('../../models/Notification');
const Application = require('../../models/Application');
const ApplicationReply = require('../../models/ApplicationReply');

module.exports = (app) => {

	app.get('/panel/applications', async (req, res) => {

		if (!await req.authenticatedUser.hasAdminPermission() && !await req.authenticatedUser.hasModPermission()) {
			return res.redirect(req.referer);
		}

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		const searchQuery = req.query.search ? req.query.search : null;

		const applications = await Application.find().sort({ createdAt: 1 });

		applications.sort((a, b) => a.status === 1 ? -1 : 0);
		applications.sort((a, b) => a.status === 2 ? -1 : 0);
		applications.sort((a, b) => a.status === 0 ? -1 : 0);

		const filteredApplications = [];
		for (const application of applications) {

			if (searchQuery) {
				const regex = new RegExp(searchQuery, 'i');
				if (!regex.test(application.fid)) {
					continue;
				}
			}

			if (!await application.isManageableBy(req.authenticatedUser)) {
				continue;
			}

			filteredApplications.push(application);

		}

		const applicationsPagination = paginate(filteredApplications, currentPage, 15, (searchQuery ? `?search=${searchQuery}&page={x}` : '?page={x}'));

		const formattedApplications = [];
		for (const application of applicationsPagination.items) {

			const replies = await ApplicationReply.find({ application: application.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;

			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedApplication = await application.format();
			formattedApplication.repliesCount = repliesCount;
			formattedApplication.latestReply = formattedLatestReply;

			formattedApplications.push(formattedApplication);

		}

		res.context.page = 'panel.applications';
		res.context.title = 'Applications';

		res.context.applications = formattedApplications;
		res.context.searchQuery = searchQuery;
		res.context.pagination = applicationsPagination.nav;
		
		res.render('panel/applications');

	});

	app.post('/panel/application/accept', csrfMiddleware, async (req, res) => {

		const applicationId = req.body.application;
		
		let application = null;
		try {
			application = await Application.findById(applicationId);
		} catch (err) { }

		if (!application) {
			return res.redirect(req.referer);
		}

		if (application.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await application.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Application.findByIdAndUpdate(application.id, {
			status: 1
		});

		if (application.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: application.author,
				title: 'Application Accepted',
				content: `Your application #${application.fid} has been accepted.`,
				link: `/application/${application.fid}`
			});
		}

		req.flash('successMessage', 'The application has been successfully accepted.');
		res.redirect(req.referer);

	});

	app.post('/panel/application/reject', csrfMiddleware, async (req, res) => {

		const applicationId = req.body.application;
		
		let application = null;
		try {
			application = await Application.findById(applicationId);
		} catch (err) { }

		if (!application) {
			return res.redirect(req.referer);
		}

		if (application.status !== 0) {
			return res.redirect(req.referer);
		}

		if (!await application.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Application.findByIdAndUpdate(application.id, {
			status: 2
		});

		if (application.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: application.author,
				title: 'Application Rejected',
				content: `Your application #${application.fid} has been rejected.`,
				link: `/application/${application.fid}`
			});
		}

		req.flash('successMessage', 'The application has been successfully rejected.');
		res.redirect(req.referer);

	});

	app.post('/panel/application/reply', csrfMiddleware, async (req, res) => {

		const applicationId = req.body.application;
		const { content } = req.body;
		
		let application = null;
		try {
			application = await Application.findById(applicationId);
		} catch (err) { }

		if (!application) {
			return res.redirect(req.referer);
		}

		if (!await application.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await ApplicationReply.create({
			author: req.authenticatedUser.id,
			application: application.id,
			content
		});

		await Application.findByIdAndUpdate(application.id);

		if (application.author !== req.authenticatedUser.id) {
			Notification.create({
				user: application.author,
				title: 'Application Reply',
				content: `${req.authenticatedUser.name} has replied to your application #${application.fid}.`,
				link: `/application/${application.fid}`
			});
		}

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});

	app.get('/panel/application/:id', async (req, res) => {

		const applicationId = req.params.id;

		let application = null;
		try {
			application = await Application.findOne({ fid: applicationId });
		} catch (err) { }

		if (!application) {
			return res.throw404();
		}

		if (!await application.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		const applicationReplies = await ApplicationReply.find({ application: application.id }).sort({ createdAt: 1 });
		const formattedApplicationReplies = [];

		for (const reply of applicationReplies) {
			const formattedReply = await reply.format();
			formattedApplicationReplies.push(formattedReply);
		}
		

		const formattedApplication = await application.format();
		formattedApplication.replies = formattedApplicationReplies;

		res.context.page = 'panel.application';
		res.context.title = `Application #${application.fid}`;
		
		res.context.application = formattedApplication;

		res.render('panel/application');

	});

}