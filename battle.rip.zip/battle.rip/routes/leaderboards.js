const fs = require('fs');
const formatPlayer = require('../utils/formatPlayer');
const getDatabaseData = require('../utils/getDatabaseData');

module.exports = (app) => {

	app.get('/:leaderboard/:extra*?', async (req, res, next) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;

		const leaderboardKey = req.params.leaderboard;
		if (!(leaderboardKey in leaderboards)) {
			return next();
		}

		res.context.page = 'leaderboards';
		res.context.title = 'Leaderboards';

		const leaderboard = leaderboards[leaderboardKey];
		await leaderboard.run(req, res);

		res.render(`leaderboards.${leaderboardKey}`);

	});

}

const leaderboards = {

	arenapvp: {
		run: async (req, res) => {

			const eloData = await getDatabaseData('arenapvp', 'elo');
			const data = await getDatabaseData('arenapvp', 'statistics');
			if (!data || data.length == 0) {
				return;
			}

			const data_ = {};
			for (const item of data) {
				for (const [key, stats] of Object.entries(item)) {
					if (typeof stats === 'object') {
						const ladder = key.toLowerCase();
						if (!(ladder in data_)) {
							data_[ladder] = [];
						}

						let elo = 1400;
						const eloData_ = eloData.find((item_) => item_._id === item._id);
						if (eloData_) {
							const elo_ = eloData_[Object.keys(eloData_).find((key) => key.toLowerCase() === ladder)];
							if (elo_) {
								elo = elo_;
							}
						}

						data_[ladder].push({
							uuid: item._id,
							name: item.name,
							elo: elo,
							wlr: stats.WLR,
							unrankedWins: stats.UNRANKED_WINS,
							unrankedWinstreak: stats.UNRANKED_WINSTREAK,
							rankedLosses: stats.RANKED_LOSSES,
							unrankedWlr: stats.UNRANKED_WLR,
							wins: stats.WINS,
							rankedWinstreak: stats.RANKED_WINSTREAK,
							highestWinstreak: stats.HIGHEST_WINSTREAK,
							rankedWlr: stats.RANKED_WLR,
							rankedHighestWinstreak: stats.RANKED_HIGHEST_WINSTREAK,
							losses: stats.UNRANKED_LOSSES,
							winstreak: stats.WINSTREAK,
							losses: stats.LOSSES,
							unrankedHighestWinstreak: stats.UNRANKED_HIGHEST_WINSTREAK,
							rankedWins: stats.RANKED_WINS
						});
					}
				}
			}
			
			for (const key of Object.keys(data_)) {
				data_[key].sort((a, b) => (b.wlr || 0) - (a.wlr || 0));
			}

			const leaderboards = {
				'global': { name: 'Global', stats: [] },
				'finaluhc': { name: 'FinalUHC', stats: [] },
				'builduhc': { name: 'BuildUHC', stats: [] },
				'nodebuff': { name: 'NoDebuff', stats: [] },
				'hg': { name: 'Hunger Games', stats: [] },
				'sg': { name: 'SurvivalGames', stats: [] },
				'archer': { name: 'Archer', stats: [] },
				'caveuhc': { name: 'CaveUHC', stats: [] },
				'skywars': { name: 'Skywars', stats: [] },
				'bedwars': { name: 'Bedwars', stats: [] },
				'uhcftrapping': { name: 'UHCF Trapping', stats: [] },
				'hcftrapping': { name: 'HCF Trapping', stats: [] }
			};

			if (req.pathArr[1]) {

				const leaderboardKey = req.pathArr[1].toLowerCase();
				const leaderboard = leaderboards[leaderboardKey];
				if (!leaderboard) {
					return;
				}

				let currentPage = 1
				if (req.query.page) {
					currentPage = parseInt(req.query.page)
				}

				let sort = 'elo';
				if (req.query.sort) {
					sort = req.query.sort.toLowerCase();
				}

				const data__ = data_[leaderboardKey];
				data__.sort((a, b) => (b[sort] || 0) - (a[sort] || 0));
	
				const dataPagination = paginate(data__, currentPage, 20, `?sort=${sort}&page={x}`);
	
				for (const [i, item] of dataPagination.items.entries()) {
					const formattedPlayer = await formatPlayer({ uuid: item.uuid, name: item.name });
					leaderboard.stats.push({
						rank: ((currentPage - 1) * 20) + (i + 1),
						player: formattedPlayer,
						elo: parseInt(item.elo) || 0,
						wlr: (parseFloat(item.wlr) || 0).toFixed(2),
						wins: parseInt(item.wins) || 0,
						losses: parseInt(item.losses) || 0,
						winstreak: parseInt(item.winstreak) || 0
					});
				}

				res.context.leaderboard = leaderboard;
				res.context.pagination = dataPagination.nav;

			} else {

				for (const [leaderboardKey, leaderboard] of Object.entries(leaderboards)) {

					const data__ = data_[leaderboardKey];
					if (!data__) {
						continue;
					}

					for (const [i, item] of data__.slice(0, 10).entries()) {
						const formattedPlayer = await formatPlayer({ uuid: item.uuid, name: item.name });
						leaderboards[leaderboardKey].stats.push({
							rank: i + 1,
							player: formattedPlayer,
							elo: parseInt(item.elo) || 0,
							wlr: (parseFloat(item.wlr) || 0).toFixed(2),
							wins: parseInt(item.wins) || 0,
							losses: parseInt(item.losses) || 0,
							winstreak: parseInt(item.winstreak) || 0
						});
					}

				}

				res.context.leaderboards = leaderboards;

			}

		}
	},
	
	uhc: {
		run: async (req, res) => {

			let currentPage = 1
			if (req.query.page) {
				currentPage = parseInt(req.query.page)
			}

			let sort = 'elo';
			if (req.query.sort) {
				sort = req.query.sort.toLowerCase();
			}

			const leaderboard = {
				name: 'UHC',
				stats: []
			};

			const data = await getDatabaseData('uhc', 'uhc_stats');
			if (!data || data.length == 0) {
				return;
			}

			data.sort((a, b) => (b.elo || 0) - (a.elo || 0));
			data.sort((a, b) => (b[sort] || 0) - (a[sort] || 0));

			const dataPagination = paginate(data, currentPage, 20, `?sort=${sort}&page={x}`);

			for (const [i, item] of dataPagination.items.entries()) {
				const formattedPlayer = await formatPlayer({ uuid: item.uuid, name: item.name });
				leaderboard.stats.push({
					rank: ((currentPage - 1) * 20) + (i + 1),
					player: formattedPlayer,
					wins: parseInt(item.wins) || 0,
					kills: parseInt(item.kills) || 0,
					deaths: parseInt(item.deaths) || 0,
					elo: parseInt(item.elo) || 0
				});
			}

			res.context.leaderboard = leaderboard;
			res.context.pagination = dataPagination.nav;

		}
	},
	
	meetup: {
		run: async (req, res) => {

			let currentPage = 1
			if (req.query.page) {
				currentPage = parseInt(req.query.page)
			}

			let sort = 'elo';
			if (req.query.sort) {
				sort = req.query.sort.toLowerCase();
			}

			const leaderboard = {
				name: 'Meetup',
				stats: []
			};

			const data = await getDatabaseData('meetup', 'meetup_stats');
			// const data = await getDatabaseData('uhc', 'uhc_stats');
			if (!data || data.length == 0) {
				return;
			}

			data.sort((a, b) => (b.elo || 0) - (a.elo || 0));
			data.sort((a, b) => (b[sort] || 0) - (a[sort] || 0));

			const dataPagination = paginate(data, currentPage, 20, `?sort=${sort}&page={x}`);

			for (const [i, item] of dataPagination.items.entries()) {
				const formattedPlayer = await formatPlayer({ uuid: item.uuid, name: item.name });
				leaderboard.stats.push({
					rank: ((currentPage - 1) * 20) + (i + 1),
					player: formattedPlayer,
					wins: parseInt(item.wins) || 0,
					kills: parseInt(item.kills) || 0,
					deaths: parseInt(item.deaths) || 0,
					elo: parseInt(item.elo) || 0
				});
			}

			res.context.leaderboard = leaderboard;
			res.context.pagination = dataPagination.nav;

		}
	}

}