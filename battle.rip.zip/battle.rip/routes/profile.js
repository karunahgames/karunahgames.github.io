const Forum = require('../models/Forum');
const ProfilePost = require('../models/ProfilePost');
const ProfilePostReply = require('../models/ProfilePostReply');
const Thread = require('../models/Thread');
const User = require('../models/User');
const Notification = require('../models/Notification');
const csrfMiddleware = require('../middlewares/csrf');
const authMiddleware = require('../middlewares/auth');
const getPlayer = require('../utils/getPlayer');
const getPlayerInfo = require('../utils/getPlayerInfo');
const formatTime = require('../utils/formatTime');
const Friend = require('../models/Friend');
const formatSocials = require('../utils/formatSocials');

module.exports = (app) => {

	app.post('/profile/post', csrfMiddleware, authMiddleware, async (req, res) => {

		const profileId = req.body.profile;
		const { content } = req.body;

		let user = null;
		try {
			user = await User.findById(profileId);
		} catch (err) { }

		if (!user) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:2048'
		})) { return };

		await ProfilePost.create({
			content,
			user: user.id,
			author: req.authenticatedUser.id
		});
		
		if (req.authenticatedUser.id !== user.id) {
			Notification.create({
				user: user.id,
				title: 'Profile Post',
				content: `${req.authenticatedUser.name} has posted on your profile.`,
				link: `/profile/${user.name}`
			});
		}

		req.flash('successMessage', 'The post has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/profile/post/edit', csrfMiddleware, authMiddleware, async (req, res) => {

		const postId = req.body.post;
		const { content } = req.body;

		let profilePost = null;
		try {
			profilePost = await ProfilePost.findById(postId);
		} catch (err) { }

		if (!profilePost) {
			return res.redirect(req.referer);
		}
		
		if (!await profilePost.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:2048'
		})) { return };

		await ProfilePost.findByIdAndUpdate(profilePost.id, {
			content,
			editedAt: new Date()
		});

		req.flash('successMessage', 'The post has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/profile/post/delete', csrfMiddleware, authMiddleware, async (req, res) => {

		const postId = req.body.post;

		let profilePost = null;
		try {
			profilePost = await ProfilePost.findById(postId);
		} catch (err) { }

		if (!profilePost) {
			return res.redirect(req.referer);
		}
		
		if (!await profilePost.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await ProfilePost.findByIdAndDelete(profilePost.id);

		req.flash('successMessage', 'The post has been successfully deleted.');
		res.redirect(req.referer);

	});

	app.post('/profile/post/reply', csrfMiddleware, authMiddleware, async (req, res) => {

		const postId = req.body.post;
		const { content } = req.body;

		let profilePost = null;
		try {
			profilePost = await ProfilePost.findById(postId);
		} catch (err) { }

		if (!profilePost) {
			return res.redirect(req.referer);
		}

		let author = null;
		try {
			author = await User.findById(profilePost.author);
		} catch (err) { }

		if (!author) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:2048'
		})) { return };
		
		await ProfilePostReply.create({
			content,
			author: req.authenticatedUser.id,
			post: profilePost.id
		});
		
		if (req.authenticatedUser.id !== profilePost.author) {
			Notification.create({
				user: author.id,
				title: 'Profile Post Reply',
				content: `${req.authenticatedUser.name} has replied to your profile post.`,
				link: `/profile/${author.name}`
			});
		}

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});
	
	app.post('/profile/post/reply/edit', csrfMiddleware, authMiddleware, async (req, res) => {

		const replyId = req.body.reply;
		const { content } = req.body;

		let profilePostReply = null;
		try {
			profilePostReply = await ProfilePostReply.findById(replyId);
		} catch (err) { }

		if (!profilePostReply) {
			return res.redirect(req.referer);
		}
		
		if (!await profilePostReply.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:2048'
		})) { return };

		await ProfilePostReply.findByIdAndUpdate(profilePostReply.id, {
			content,
			editedAt: new Date()
		});

		req.flash('successMessage', 'The reply has been successfully edited.');
		res.redirect(req.referer);

	});
	
	app.post('/profile/post/reply/delete', csrfMiddleware, authMiddleware, async (req, res) => {

		const replyId = req.body.reply;

		let profilePostReply = null;
		try {
			profilePostReply = await ProfilePostReply.findById(replyId);
		} catch (err) { }

		if (!profilePostReply) {
			return res.redirect(req.referer);
		}
		
		if (!await profilePostReply.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await ProfilePostReply.findByIdAndDelete(profilePostReply.id);

		req.flash('successMessage', 'The reply has been successfully deleted.');
		res.redirect(req.referer);

	});

	app.get('/profile/:username/:tab*?', async (req, res) => {

		const { username } = req.params;

		const playerInfo = await getPlayerInfo(username);
		if (!playerInfo) {
			return res.throw404();
		}

		const player = await getPlayer(playerInfo.uuid);
		if (!player) {
			return res.throw404();
		}

		const user = await User.findOne({ uuid: playerInfo.uuid });
		const formattedUser = await user?.format();

		const isBanned = false;
		const isOnline = false;
		const firstJoinedAt = player.firstJoin;
		const lastSeenAt = player.lastSeen;
		const lastServer = null;

		let isSelf = false;
		if (req.isUserAuthenticated && user && user.id === req.authenticatedUser.id) {
			isSelf = true;
		}

		const formattedPlayer = await formatPlayer(player);
		formattedPlayer.isRegistered = Boolean(user);
		formattedPlayer.isBanned = isBanned;
		formattedPlayer.isOnline = isOnline;
		formattedPlayer.firstJoinedAt = formatTime(firstJoinedAt);
		formattedPlayer.lastSeenAt = formatTime(lastSeenAt);
		formattedPlayer.lastServer = lastServer;

		const profile = {
			id: user?.id,
			uuid: playerInfo.uuid,
			name: playerInfo.name,
			link: `/profile/${playerInfo.name}`,
			player: formattedPlayer,
			user: formattedUser,
			socials: formatSocials(user?.socials),
			isSelf: Boolean(isSelf)
		};

		/* --- */

		profile.friends = [];
		profile.friend = null;

		if (user) {

			const friends = await Friend.getFriends(user.id);
			const formattedFriends = await Promise.all(friends.map((friend) => friend.format()));
			
			profile.friends = formattedFriends;

			if (req.isUserAuthenticated) {

				const friend = await Friend.findOne({
					$and: [
						{ $or: [
							{ requester: user.id, recipient: req.authenticatedUser.id },
							{ recipient: user.id, requester: req.authenticatedUser.id }
						] },
						{ $or: [
							{ status: 0 },
							{ status: 1 }
						] }
					]
				});

				if (friend) {
					profile.friend = await friend?.format();
				}

			}

		}

		/* --- */

		const activeTabKey = req.params.tab ?? Object.keys(profileTabs)[0];

		const tabs = [];
		for (const [tabKey, tab] of Object.entries(profileTabs)) {
			tabs.push({
				name: tab.name,
				template: `profile.${tabKey}`,
				link: `/profile/${playerInfo.name}/${tabKey}`,
				active: tabKey === activeTabKey
			});
		}

		const activeTab = profileTabs[activeTabKey];
		if (!activeTab) {
			res.throw404();
		}

		await activeTab.run(req, res, player, user, profile);

		/* --- */

		res.context.page = 'profile';
		res.context.title = `${playerInfo.name}'s Profile`;

		res.context.profile = profile;
		res.context.tabs = tabs;
		res.context.activeTab = tabs.find((tab) => tab.active);

		res.render('profile');

	});

}

const profileTabs = {

	'general': {
		name: 'General',
		run: async (req, res, player, user, profile) => {

			profile.posts = [];

			if (user) {

				const profilePosts = await ProfilePost.find({ user: user.id }).sort({ createdAt: -1 });
				const formattedProfilePosts = [];

				for (const profilePost of profilePosts) {

					const profilePostReplies = await ProfilePostReply.find({ post: profilePost.id }).sort({ createdAt: 1 });
					const formattedProfilePostReplies = [];

					for (const profilePostReply of profilePostReplies) {
						const formattedProfilePostReply = await profilePostReply.format();
						formattedProfilePostReply.isManageable = await profilePostReply.isManageableBy(req.authenticatedUser);
						formattedProfilePostReplies.push(formattedProfilePostReply);
					}

					const formattedProfilePost = await profilePost.format();
					formattedProfilePost.isManageable = await profilePost.isManageableBy(req.authenticatedUser);
					formattedProfilePost.replies = formattedProfilePostReplies;

					formattedProfilePosts.push(formattedProfilePost);

				}
			
				profile.posts = formattedProfilePosts;

			}

		}
	},

	'statistics': {
		name: 'Statistics',
		run: async (req, res, player, user, profile) => {

			let activeStatistic = 'arenapvp';
			if (req.pathArr[3]) {
				activeStatistic = req.pathArr[3].toLowerCase();
			}

			if (activeStatistic === 'arenapvp') {

				profile.activeStatistic = 'arenapvp';
				profile.statistics = [];

				const data = (await getDatabaseData('arenapvp', 'statistics', { _id: player.uuid }))[0];
				if (!data) {
					return;
				}

				const statistics = {
					'global': { name: 'Global', stats: { } },
					'finaluhc': { name: 'FinalUHC', stats: { } },
					'builduhc': { name: 'BuildUHC', stats: { } },
					'nodebuff': { name: 'No Debuff', stats: { } },
					'hg': { name: 'Hunger Games', stats: { } },
					'sg': { name: 'Survival Games', stats: { } },
					'archer': { name: 'Archer', stats: { } },
					'caveuhc': { name: 'CaveUHC', stats: { } },
					'skywars': { name: 'Skywars', stats: { } },
					'bedwars': { name: 'Bedwars', stats: { } },
					'uhctrapping': { name: 'UHC Trapping', stats: { } },
					'hcftrapping': { name: 'HCF Trapping', stats: { } }
				};

				for (const [key, stats] of Object.entries(data)) {
					const prop = key.toLowerCase();
					if (prop in statistics) {
						statistics[prop].stats = {
							wlr: parseInt(stats.WLR) || 0,
							wins: parseInt(stats.WINS) || 0,
							losses: parseInt(stats.UNRANKED_LOSSES) || 0,
							winstreak: parseInt(stats.WINSTREAK) || 0,
							losses: parseInt(stats.LOSSES) || 0
						}
					}
				}

				profile.statistics = statistics;

			} else if (activeStatistic === 'uhc') {
				
				profile.activeStatistic = 'uhc';
				profile.statistics = [];

				const data = (await getDatabaseData('uhc', 'uhc_stats', { uuid: player.uuid }))[0];
				if (!data) {
					return;
				}

				const statistics = {
					'wins': parseInt(data.wins) || 0,
					'deaths': parseInt(data.deaths) || 0,
					'kills': parseInt(data.kills) || 0,
					'elo': parseFloat(data.elo) || 0,
					'gamesPlayed': parseInt(data.games_played) || 0
				};

				profile.statistics = statistics;

			} else if (activeStatistic === 'meetup') {
				
				profile.activeStatistic = 'meetup';
				profile.statistics = [];

				const data = (await getDatabaseData('meetup', 'meetup_stats', { uuid: player.uuid }))[0];
				if (!data) {
					return;
				}

				const statistics = {
					'wins': parseInt(data.wins) || 0,
					'deaths': parseInt(data.deaths) || 0,
					'kills': parseInt(data.kills) || 0,
					'elo': parseFloat(data.elo) || 0,
					'gamesPlayed': parseInt(data.games_played) || 0
				};

				profile.statistics = statistics;

			}

		}
	},

	'forum': {
		name: 'Forum',
		run: async (req, res, player, user, profile) => {

			profile.threads = [];

			if (user) {

				const threads = await Thread.find({ author: user.id }).sort({ createdAt: -1 });
				const formattedThreads = [];

				for (const thread of threads) {

					const forum = await Forum.findById(thread.forum);
					if (forum) {
						const formattedThread = await thread.format();
						formattedThreads.push(formattedThread);
					}

				}

				profile.threads = formattedThreads;

			}

		}
	}

}
