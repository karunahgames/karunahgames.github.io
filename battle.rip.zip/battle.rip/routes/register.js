const Setting = require('../models/Setting');
const User = require('../models/User');
const UserRegistration = require('../models/UserRegistration');
const hashPassword = require('../utils/hashPassword');
const sendMail = require('../utils/sendMail');
const config = require('../config.json');

module.exports = (app) => {

	app.get('/register', (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(res.referer);
		}

		res.context.page = 'register';
		res.context.title = 'Register';

		res.render('register');

	});

	app.post('/register', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(res.referer);
		}

		const authKey = req.headers['auth-key'];
		
		const { uuid, name, email } = req.body;

		if (!authKey) {
			return res.json('error', 'missingAuthKey');
		}

		if (authKey !== config.apiAuthKey) {
			return res.json('error', 'invalidAuthKey');
		}

		if (!uuid || !name || !email) {
			return res.json('error', 'invalidBody');
		}

		if (!isValidEmail(email)) {
			return res.json('error', 'invalidEmail');
		}

		let user = await User.findOne({ uuid });
		if (user) {
			return res.json('error', 'userAlreadyRegistered');
		}

		let userRegistration = await UserRegistration.findOne({ uuid });
		if (!userRegistration) {

			const userWithSameEmail = await User.findOne({ email });
			if (userWithSameEmail) {
				return res.json('error', 'emailAlreadyInUse');
			}

			userRegistration = await UserRegistration.create({ uuid, name, email });

		}

		if (userRegistration.email !== email) {

			const userWithSameEmail = await User.findOne({ email });
			if (userWithSameEmail) {
				return res.json('error', 'emailAlreadyInUse');
			}

			await UserRegistration.findByIdAndUpdate(userRegistration.id, { email });

		}

		const settings = await Setting.getSettings();

		const registerationLink = `${settings.siteLink}/register/${userRegistration.code}`;
		
		const emailSent = await sendMail({
			email: email, 
			subject: `Confirm your ${settings.siteName} account`, 
			body: `
				<strong>Hello ${name}!</strong>
				<br />
				To finish registration of your ${settings.siteName} account,
				please click <a href="${registerationLink}">here</a>!
				<br />
				<br />
				Thanks,
				<br />
				${settings.siteName}.
			`
		});

		if (!emailSent) {
			return res.json('error', 'emailDeliveryFailed');
		}

		return res.json('success');

	});

	app.get('/register/:code', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(req.referer);
		}

		const registerationCode = req.params.code;

		const userRegistration = await UserRegistration.findOne({ code: registerationCode });
		if (!userRegistration) {
			return res.throw404();
		}

		// const user = await User.findOne({ uuid: userRegistration.uuid });
		// if (user) {
		// 	return res.throw404();
		// }

		const formattedUserRegistration = await userRegistration.format();

		res.context.page = 'register';
		res.context.title = 'Register';
		
		res.context.registration = formattedUserRegistration;

		res.render('register.complete');

	});

	app.post('/register/:code', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(req.referer);
		}

		const registrationCode = req.params.code;

		const { password } = req.body;

		const userRegistration = await UserRegistration.findOne({ code: registrationCode });
		if (!userRegistration) {
			return res.redirect(res.referer);
		}

		const user = await User.findOne({ uuid: userRegistration.uuid });
		if (user) {
			return res.throw404();
		}

		if (!await req.validateInput({
			password: 'required|minLength:3|maxLength:32',
			confirmPassword: 'required|same:password'
		})) { return };

		const hashedPassword = await hashPassword(password);

		await User.create({
			uuid: userRegistration.uuid,
			name: userRegistration.name,
			email: userRegistration.email,
			password: hashedPassword,
			isActive: true
		});
		
		req.flash('successMessage', 'Registration has been completed, you can now login.');
		res.redirect('/login');

	});

}

const isValidEmail = (email) => {

	const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	return !!email && typeof email === 'string' && email.match(emailRegex);

};