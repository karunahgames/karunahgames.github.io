const csrfMiddleware = require('../middlewares/csrf');
const authMiddleware = require('../middlewares/auth');
const Notification = require('../models/Notification');

module.exports = (app) => {

	app.get('/notifications', authMiddleware, async (req, res) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;

		const notifications = await Notification.find({ user: req.authenticatedUser.id }).sort({ isRead: 1, createdAt: -1 });
		const notificationsPagination = paginate(notifications, currentPage, 15, '?page={x}');
		const formattedNotifications = await Promise.all(notificationsPagination.items.map((notification) => notification.format()));

		Notification.updateMany({ user: req.authenticatedUser.id, isRead: false }, { isRead: true })
			.then(() => {}).catch(() => {});

		res.context.page = 'notifications';
		res.context.title = 'Notifications';

		res.context.notifications = formattedNotifications;
		res.context.pagination = notificationsPagination.nav;

		res.render('notifications');

	});

	app.get('/notification/:id', authMiddleware, async (req, res) => {

		const notificationId = req.params.id;

		let notification = null;
		try {
			notification = await Notification.findOne({ fid: notificationId });
		} catch (err) { }

		if (!notification) {
			return res.redirect(req.referer);
		}

		if (notification.user !== req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		await Notification.findByIdAndUpdate(notification.id, { isRead: true });

		res.redirect(notification.link);

	});

}
