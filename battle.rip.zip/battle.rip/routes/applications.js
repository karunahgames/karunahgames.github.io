const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const Application = require('../models/Application');
const ApplicationCategory = require('../models/ApplicationCategory');
const ApplicationReply = require('../models/ApplicationReply');

module.exports = (app) => {

	app.get('/applications', authMiddleware, async (req, res) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		
		const applications = await Application.find({ author: req.authenticatedUser.id }).sort({ createdAt: 1 });
		applications.sort((a, b) => a.status === 1 ? -1 : 0);
		applications.sort((a, b) => a.status === 2 ? -1 : 0);
		applications.sort((a, b) => a.status === 0 ? -1 : 0);

		const applicationsPagination = paginate(applications, currentPage, 15, `?page={x}`);
		const formattedApplications = [];

		for (const application of applicationsPagination.items) {

			const replies = await ApplicationReply.find({ application: application.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;
			
			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedApplication = await application.format();
			formattedApplication.repliesCount = repliesCount;
			formattedApplication.latestReply = formattedLatestReply;

			formattedApplications.push(formattedApplication);

		}

		res.context.page = 'applications';
		res.context.title = 'Applications';

		res.context.applications = formattedApplications;
		res.context.pagination = applicationsPagination.nav;

		res.render('applications');

	});

	app.get('/application/new/:slug', authMiddleware, async (req, res) => {

		const applicationCategorySlug = req.params.slug;

		const applicationCategory = await ApplicationCategory.findOne({ slug: applicationCategorySlug });
		if (!applicationCategory) {
			return res.throw404();
		}

		const formattedApplicationCategory = await applicationCategory.format();

		res.context.page = 'applications.new';
		res.context.title = 'New Application';

		res.context.applicationCategory = formattedApplicationCategory;

		res.render('application.new');

	});

	app.post('/application/new', csrfMiddleware, authMiddleware, async (req, res) => {

		const categoryId = req.body.category;
		const { answers } = req.body;

		let applicationCategory = null;
		try {
			applicationCategory = await ApplicationCategory.findById(categoryId);
		} catch (error) { }

		if (!applicationCategory) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			answers: 'required',
		})) { return };

		let questions = [];
		try {
			questions = JSON.parse(applicationCategory.questions);
		} catch (err) { }

		const qna = [];
		for (const [i, question] of questions.entries()) {

			const answer = answers[i];

			const answerValidation = await validateAnswer(i, question, answer);
			if (!answerValidation.success) {
				return res.redirect(req.referer);
			}
		
			qna.push([question.question, answer]);

		}

		const application = await Application.create({
			category: applicationCategory.id,
			author: req.authenticatedUser.id,
			qna
		});

		req.flash('successMessage', 'The application has been successfully created.');
		res.redirect(`/application/${application.fid}`);

	});

	app.post('/application/validate', csrfMiddleware, authMiddleware, async (req, res) => {

		const categoryId = req.body.category;
		const { answers } = req.body;

		let applicationCategory = null;
		try {
			applicationCategory = await ApplicationCategory.findById(categoryId);
		} catch (error) { }

		if (!applicationCategory) {
			return res.json('error');
		}

		let questions = [];
		try {
			questions = JSON.parse(applicationCategory.questions);
		} catch (err) {}

		for (const [i, question] of questions.entries()) {

			const answer = answers ? answers[i] : null;

			const answerValidation = await validateAnswer(i, question, answer);
			if (answerValidation.error) {
				return res.json('error', answerValidation.error);
			}

		}

		res.json('success');

	});

	app.post('/application/reply', csrfMiddleware, authMiddleware, async (req, res) => {

		const applicationId = req.body.application;
		const { content } = req.body;
		
		let application = null;
		try {
			application = await Application.findById(applicationId);
		} catch (err) { }

		if (!application) {
			return res.redirect(req.referer);
		}

		if (application.author !== req.authenticatedUser.id) {
			return res.throw404();
		}

		if (application.status !== 0) {
			return res.redirect(req.referer);
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await ApplicationReply.create({
			author: req.authenticatedUser.id,
			application: application.id,
			content
		});

		await Application.findByIdAndUpdate(application.id);

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});
	
	app.get('/application/:id', authMiddleware, async (req, res) => {

		const applicationId = req.params.id;

		let application = null;
		try {
			application = await Application.findOne({ fid: applicationId });
		} catch (err) { }

		if (!application) {
			return res.throw404();
		}

		if (application.author !== req.authenticatedUser.id) {
			return res.throw404();
		}

		const applicationCategory = await ApplicationCategory.findById(application.category);
		if (!applicationCategory) {
			return res.throw404();
		}

		const applicationReplies = await ApplicationReply.find({ application: application.id }).sort({ createdAt: 1 });
		const formattedApplicationReplies = [];

		for (const reply of applicationReplies) {
			const formattedReply = await reply.format();
			formattedReply.isManageable = await reply.isManageableBy(req.authenticatedUser);
			formattedApplicationReplies.push(formattedReply);
		}
		
		const formattedApplication = await application.format();
		formattedApplication.isManageable = await application.isManageableBy(req.authenticatedUser);
		formattedApplication.replies = formattedApplicationReplies;

		res.context.page = 'application';
		res.context.title = `Application #${application.fid}`;
		
		res.context.application = formattedApplication;

		res.render('application');

	});

}

const validateAnswer = (i, question, answer) => {

	const qn = i + 1; // (qn = question number)

	if (answer == undefined || answer == null || answer == '') {
		return { success: false, error: `Question ${qn} is required.` };
	}

	if (question.type === 'number') {

		const number = parseFloat(answer);
		if (!number) {
			return { success: false, error: `Question ${qn} must have a numeric value.` };
		}

		if (question.minlength && number < question.minlength) {
			return { success: false, error: `Question ${qn} must have a value greater than ${question.minlength}.` };
		}

		if (question.maxlength && number > question.maxlength) {
			return { success: false, error: `Question ${qn} must not have a value greater than ${question.maxlength}.` };
		}

	} else if (question.type === 'text') {

		if (question.minlength && answer.length < question.minlength) {
			return { success: false, error: `Question ${qn} must be greater than ${question.minlength}.` };
		}

		if (question.maxlength && answer.length > question.maxlength) {
			return { success: false, error: `Question ${qn} must not be greater than ${question.maxlength}.` };
		}

	} else if (question.type === 'bigtext') {

		if (question.minlength && answer.length < question.minlength) {
			return { success: false, error: `Question ${qn} must be greater than ${question.minlength}.` };
		}

		if (question.maxlength && answer.length > question.maxlength) {
			return { success: false, error: `Question ${qn} must not be greater than ${question.maxlength}.` };
		}

	} else if (question.type === 'option') {

		// ...
		
	} else if (question.type === 'multioption') {

		// ...
		
	}

	return { success: true };

}