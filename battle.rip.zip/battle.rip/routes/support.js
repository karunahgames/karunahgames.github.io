const ApplicationCategory = require('../models/ApplicationCategory');
const TicketCategory = require('../models/TicketCategory');

module.exports = (app) => {

	app.get('/support', async (req, res) => {

		const ticketCategories = await TicketCategory.find();
		const formattedTicketCategories = await Promise.all(ticketCategories.map((category) => category.format()));

		const applicationCategories = await ApplicationCategory.find();
		const formattedApplicationCategories = await Promise.all(applicationCategories.map((category) => category.format()));

		res.context.page = 'support';
		res.context.title = 'Support';

		res.context.ticketCategories = formattedTicketCategories;
		res.context.applicationCategories = formattedApplicationCategories;

		res.render('support');

	});

}
