const User = require('../models/User');

module.exports = (app) => {

	app.get('/search/:query', async (req, res) => {

		const searchQuery = req.params.query;

		if (!searchQuery) {
			return res.json('error', 'invalidParams');
		}

		const usersData = [];

		const users = await User.find({ name: { '$regex': searchQuery, '$options': 'i' } });
		if (users) {
			for (const user of users) {
				const formattedUser = await user.format();
				usersData.push({
					uuid: formattedUser.uuid,
					name: formattedUser.name,
					color: formattedUser.color,
					link: formattedUser.link,
					html: formattedUser.html,
					avatar: formattedUser.avatar
				})
			}
		}

		res.json('success', { users: usersData });

	});

}