const bcrypt = require('bcrypt');
const csrfMiddleware = require('../middlewares/csrf');
const User = require('../models/User');
const sendMail = require('../utils/sendMail');
const UserPasswordReset = require('../models/UserPasswordReset');
const Setting = require('../models/Setting');
const hashPassword = require('../utils/hashPassword');

module.exports = (app) => {

	app.get('/reset', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(req.referer);
		}

		res.context.page = 'reset';
		res.context.title = 'Reset Password';

		res.render('reset');

	});

	app.post('/reset', csrfMiddleware, async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect('/');
		}

		const { email } = req.body;

		if (!await req.validateInput({
			email: 'required|email'
		})) { return };

		const user = await User.findOne({ email });
		if (!user) {
			req.flash('errorMessage', 'Could not find an account with that email.');
			return res.redirect(req.referer);
		}

		if (!user.isActive) {
			req.flash('errorMessage', 'That account is not active.');
			return res.redirect(req.referer);
		}

		await UserPasswordReset.updateMany({ user: user.id }, { isExpired: true });
		
		const settings = await Setting.getSettings();

		const userPasswordReset = await UserPasswordReset.create({
			user: user.id
		});

		const userPasswordResetLink = `${settings.siteLink}/reset/${userPasswordReset.code}`;

		const emailSent = await sendMail({
			email: user.email, 
			subject: `Reset your ${settings.siteName} password`, 
			body: `
				<strong>Hello ${user.name}!</strong>
				<br />
				To reset your ${settings.siteName} account's password,
				please click <a href="${userPasswordResetLink}">here</a>!
				<br />
				<br />
				Thanks,
				<br />
				${settings.siteName}.
			`
		});

		if (!emailSent) {
			req.flash('errorMessage', 'An error occured while sending the email. Please contact an admin.');
			return res.redirect(req.referer);
		}

		req.flash('successMessage', 'You have been emailed with a link to reset your password.');
		res.redirect(req.referer);

	});

	app.get('/reset/:code', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect('/');
		}

		const resetCode = req.params.code;

		const userPasswordReset = await UserPasswordReset.findOne({ code: resetCode, isExpired: false });
		if (!userPasswordReset) {
			return res.throw404();
		}

		const formattedUserPasswordReset = await userPasswordReset.format();

		res.context.page = 'reset';
		res.context.title = 'Reset Password';

		res.context.passwordReset = formattedUserPasswordReset;
		
		res.render('reset.complete');

	});

	app.post('/reset/:code', csrfMiddleware, async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect('/');
		}

		const resetCode = req.params.code;

		const { password, confirmPassword } = req.body;

		const userPasswordReset = await UserPasswordReset.findOne({ code: resetCode, isExpired: false });
		if (!userPasswordReset) {
			return res.throw404();
		}

		if (!await req.validateInput({
			password: 'required|minLength:3|maxLength:32',
			confirmPassword: 'required|same:password'
		})) { return };

		const user = await User.findById(userPasswordReset.user);
		if (!user) {
			return res.throw404();
		}

		const hashedPassword = await hashPassword(password);

		await User.findByIdAndUpdate(user.id, { password: hashedPassword });
		await UserPasswordReset.findByIdAndUpdate(userPasswordReset.id, { isExpired: true });

		req.flash('successMessage', 'The password has been successfully reset.');
		res.redirect('/login');

	});

}