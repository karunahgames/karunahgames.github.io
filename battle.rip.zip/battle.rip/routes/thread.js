const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const Forum = require('../models/Forum');
const ForumCategory = require('../models/ForumCategory');
const Notification = require('../models/Notification');
const Thread = require('../models/Thread');
const ThreadReply = require('../models/ThreadReply');

module.exports = (app) => {

	app.get('/thread/new/:slug?', authMiddleware, async (req, res) => {

		const selectedForumSlug = req.params.slug;
		
		const forumCategories = await ForumCategory.find().sort({ order: 1 });

		const formattedForumCategories = [];
		for (const forumCategory of forumCategories) {

			const forums = await Forum.find({ category: forumCategory.id }).sort({ order: 1 });
			const formattedForums = [];

			for (const forum of forums) {

				if (forum.redirectUrl || (forum.isRestricted && !await req.authenticatedUser.hasAdminPermission())) {
					continue;
				}

				const formattedForum = await forum.format();
				formattedForums.push(formattedForum);

			}

			const formattedForumCategory = await forumCategory.format();
			formattedForumCategory.forums = formattedForums;

			formattedForumCategories.push(formattedForumCategory);

		}

		const selectedForum = selectedForumSlug ? await Forum.findOne({ slug: selectedForumSlug }) : null;
		const formattedSelectedForum = await selectedForum?.format();

		res.context.page = 'thread.new';
		res.context.title = 'Forums';

		res.context.forumCategories = formattedForumCategories;
		res.context.selectedForum = formattedSelectedForum;

		res.render('thread.new');

	});

	app.post('/thread/new', csrfMiddleware, authMiddleware, async (req, res) => {

		const forumId = req.body.forum;
		const { title, content } = req.body;

		let forum = null;
		try {
			forum = await Forum.findById(forumId);
		} catch (err) { }

		if (!forum) {
			return res.redirect(req.referer);
		}

		if (forum.redirectUrl) {
			return res.redirect(req.referer);
		}

		if (forum.isRestricted && !await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			title: 'required|minLength:1|maxLength:64',
			content: 'required|minLength:1|maxLength:4096',
			forum: 'required'
		})) { return };

		const thread = await Thread.create({
			title,
			content,
			author: req.authenticatedUser.id,
			forum: forum.id
		});

		req.flash('successMessage', 'The thread has been successfully created.');
		res.redirect(`/thread/${thread.fid}`);

	});

	app.post('/thread/edit', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;
		const { title, content } = req.body;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }

		if (!thread) {
			return res.redirect(req.referer);
		}

		if (!await thread.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			title: 'required|minLength:1|maxLength:64',
			content: 'required|minLength:1|maxLength:4096'
		})) { return };

		await Thread.findByIdAndUpdate(thread.id, {
			title,
			content,
			editedAt: new Date()
		});

		req.flash('successMessage', 'The thread has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/thread/delete', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }

		if (!thread) {
			return res.redirect(req.referer);
		}

		if (!await thread.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await Thread.findByIdAndDelete(thread.id);

		req.flash('successMessage', 'The thread has been successfully deleted.');
		res.redirect('/forums');

	});
	
	app.post('/thread/pin', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }

		if (!thread) {
			return res.redirect(req.referer);
		}
		
		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		await Thread.findByIdAndUpdate(thread.id, { isPinned: !thread.isPinned });

		req.flash('successMessage', 'The thread has been successfully pinned.');
		res.redirect(req.referer);

	});

	app.post('/thread/feature', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }

		if (!thread) {
			return res.redirect(req.referer);
		}
		
		if (!await req.authenticatedUser.hasAdminPermission()) {
			return res.redirect(req.referer);
		}

		await Thread.findByIdAndUpdate(thread.id, { isFeatured: !thread.isFeatured });

		req.flash('successMessage', 'The thread has been successfully featured.');
		res.redirect(req.referer);

	});

	app.post('/thread/upvote', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }
		
		if (!thread) {
			return res.redirect(req.referer);
		}

		const upvotes = thread.upvotes;

		if (upvotes.includes(req.authenticatedUser.id)) {
			upvotes.splice(upvotes.indexOf(req.authenticatedUser.id), 1);
		} else {
			upvotes.push(req.authenticatedUser.id);
		}

		await Thread.findByIdAndUpdate(thread.id, { upvotes });

		res.redirect(req.referer);

	});

	app.post('/thread/reply', csrfMiddleware, authMiddleware, async (req, res) => {

		const threadId = req.body.thread;
		const { content } = req.body;

		let thread = null;
		try {
			thread = await Thread.findById(threadId);
		} catch (err) { }

		if (!thread) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return }

		await ThreadReply.create({
			author: req.authenticatedUser.id,
			thread: thread.id,
			content
		});
		
		if (req.authenticatedUser.id !== thread.author) {
			Notification.create({
				user: thread.author,
				title: 'Thread Reply',
				content: `${req.authenticatedUser.name} has replied to your thread.`,
				link: `/thread/${thread.fid}`
			});
		}
		
		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});
	
	app.post('/thread/reply/edit', csrfMiddleware, authMiddleware, async (req, res) => {

		const replyId = req.body.reply;
		const { content } = req.body;

		let threadReply = null;
		try {
			threadReply = await ThreadReply.findById(replyId);
		} catch (err) { }

		if (!threadReply) {
			return res.redirect(req.referer);
		}

		if (!await threadReply.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await ThreadReply.findByIdAndUpdate(threadReply.id, {
			content,
			editedAt: new Date()
		});

		req.flash('successMessage', 'The reply has been successfully edited.');
		res.redirect(req.referer);

	});

	app.post('/thread/reply/delete', csrfMiddleware, authMiddleware, async (req, res) => {

		const replyId = req.body.reply;

		let threadReply = null;
		try {
			threadReply = await ThreadReply.findById(replyId);
		} catch (err) { }

		if (!threadReply) {
			return res.redirect(req.referer);
		}

		if (!await threadReply.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await ThreadReply.findByIdAndDelete(threadReply.id);

		req.flash('successMessage', 'The reply has been successfully deleted.');
		res.redirect(req.referer);

	});

	app.get('/thread/:id/:extra?', async (req, res) => {

		const threadId = req.params.id;

		const thread = await Thread.findOne({ fid: threadId });
		if (!thread) {
			return res.throw404();
		}

		const forum = await Forum.findById(thread.forum);
		if (!forum) {
			return res.throw404();
		}

		const threadReplies = await ThreadReply.find({ thread: thread.id }).sort({ upvotes: -1, createdAt: 1 });
		const formattedThreadReplies = [];

		for (const threadReply of threadReplies) {
			const formattedThreadReply = await threadReply.format();
			formattedThreadReply.isManageable = await threadReply.isManageableBy(req.authenticatedUser);
			formattedThreadReplies.push(formattedThreadReply);
		}

		const formattedThread = await thread.format();
		formattedThread.isManageable = await thread.isManageableBy(req.authenticatedUser);
		formattedThread.replies = formattedThreadReplies;

		res.context.page = 'thread';
		res.context.title = thread.title;

		res.context.thread = formattedThread;

		res.render('thread');

	});

}