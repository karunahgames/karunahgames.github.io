module.exports = (app) => {

	app.get('/staff-applications', async (req, res) => {
		res.redirect('/application/new/staff');
	});

	app.get('/media-applications', async (req, res) => {
		res.redirect('/application/new/media');
	});

	app.get('/discord', async (req, res) => {
		res.redirect('https://discord.gg/MPpUPxq3RV');
	});

	app.get('/store', async (req, res) => {
		res.redirect('https://battle.tebex.io');
	});

}
