const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const Friend = require('../models/Friend');
const Notification = require('../models/Notification');
const User = require('../models/User');

module.exports = (app) => {

	app.post('/friends/add', csrfMiddleware, authMiddleware, async (req, res) => {

		const userId = req.body.user;

		let user = null;
		try {
			user = await User.findById(userId);
		} catch (err) { }

		if (!user) {
			return res.redirect(req.referer);
		}
		
		if (user.id === req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		const friend = await Friend.findOne({
			$and: [
				{ $or: [
					{ requester: user.id, recipient: req.authenticatedUser.id },
					{ recipient: user.id, requester: req.authenticatedUser.id }
				] },
				{ $or: [
					{ status: 0 },
					{ status: 1 }
				] }
			]
		});

		if (friend) {
			return res.redirect(req.referer);
		}

		await Friend.create({
			requester: req.authenticatedUser.id,
			recipient: user.id
		});

		Notification.create({
			user: user.id,
			title: 'Friend Request',
			content: `${req.authenticatedUser.name} has sent you a friend request.`,
			link: '/friends/requests'
		});

		req.flash('successMessage', 'Friend request has been successfully sent.');
		res.redirect(req.referer);

	});
	
	app.post('/friends/accept', csrfMiddleware, authMiddleware, async (req, res) => {

		const friendId = req.body.friend;

		let friend = null;
		try {
			friend = await Friend.findById(friendId);
		} catch (error) { }
		
		if (!friend) {
			return res.redirect(req.referer);
		}

		if (friend.status !== 0) {
			return res.redirect(req.referer);
		}

		if (friend.recipient !== req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		await Friend.findByIdAndUpdate(friend.id, { status: 1 });

		Notification.create({
			user: friend.requester,
			title: 'Friend Request',
			content: `${req.authenticatedUser.name} has accepted your friend request.`,
			link: '/friends'
		});

		req.flash('successMessage', 'Friend request has been successfully accepted.');
		res.redirect(req.referer);

	});

	app.post('/friends/reject', csrfMiddleware, authMiddleware, async (req, res) => {

		const friendId = req.body.friend;

		let friend = null;
		try {
			friend = await Friend.findById(friendId);
		} catch (error) { }

		if (!friend) {
			return res.redirect(req.referer);
		}

		if (friend.status !== 0) {
			return res.redirect(req.referer);
		}

		if (friend.recipient !== req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		await Friend.findByIdAndUpdate(friend.id, { status: 2 });

		req.flash('successMessage', 'Friend request has been successfully rejected.');
		res.redirect(req.referer);

	});
	
	app.post('/friends/cancel', csrfMiddleware, authMiddleware, async (req, res) => {

		const friendId = req.body.friend;

		let friend = null;
		try {
			friend = await Friend.findById(friendId);
		} catch (error) { }
		
		if (!friend) {
			return res.redirect(req.referer);
		}

		if (friend.status !== 0) {
			return res.redirect(req.referer);
		}

		if (friend.requester !== req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		await Friend.findByIdAndUpdate(friend.id, { status: 3 });

		req.flash('successMessage', 'Friend request has been successfully cancelled.');
		res.redirect(req.referer);

	});
	
	app.post('/friends/remove', csrfMiddleware, authMiddleware, async (req, res) => {

		const friendId = req.body.friend;

		let friend = null;
		try {
			friend = await Friend.findById(friendId);
		} catch (error) { }
		
		if (!friend) {
			return res.redirect(req.referer);
		}

		if (friend.status !== 1) {
			return res.redirect(req.referer);
		}

		if (friend.requester !== req.authenticatedUser.id && friend.recipient !== req.authenticatedUser.id) {
			return res.redirect(req.referer);
		}

		await Friend.findByIdAndUpdate(friend.id, { status: 3 });

		req.flash('successMessage', 'Friend has been successfully removed.');
		res.redirect(req.referer);

	});

	app.get('/friends/:tab?', authMiddleware, async (req, res) => {

		// const currentPage = req.query.page ? parseInt(req.query.page) : 1;

		let currentTab = req.params.tab;
		if (!['all', 'requests', 'requests-sent'].includes(currentTab)) {
			currentTab = 'all';
		}

		if (currentTab === 'all') {

			const friends = await Friend.find({
				$or: [
					{ requester: req.authenticatedUser.id },
					{ recipient: req.authenticatedUser.id }
				]
			});

			const formattedFriends = [];
			for (const friend of friends) {

				if (friend.status !== 1) {
					continue;
				}

				const formattedFriend = await friend.format();

				formattedFriend.user = formattedFriend.requester;
				if (friend.requester === req.authenticatedUser.id) {
					formattedFriend.user = formattedFriend.recipient;
				}

				formattedFriends.push(formattedFriend);

			}

			res.context.friends = formattedFriends;

		} else if (currentTab === 'requests') {

			const friends = await Friend.find({ recipient: req.authenticatedUser.id });

			const formattedFriends = [];
			for (const friend of friends) {

				if (friend.status !== 0) {
					continue;
				}

				const formattedFriend = await friend.format();
				formattedFriends.push(formattedFriend);

			}

			res.context.friends = formattedFriends;


		} else if (currentTab === 'requests-sent') {

			const friends = await Friend.find({ requester: req.authenticatedUser.id });

			const formattedFriends = [];
			for (const friend of friends) {

				if (friend.status !== 0) {
					continue;
				}

				const formattedFriend = await friend.format();
				formattedFriends.push(formattedFriend);

			}

			res.context.friends = formattedFriends;

		}

		res.context.page = 'friends';
		res.context.title = 'Friends';

		res.context.currentTab = currentTab;
		
		res.render('friends');

	});

}