const Rank = require('../models/Rank');
const getPlayers = require('../utils/getPlayers');
const getPlayerRanks = require('../utils/getPlayerRanks');
const formatPlayer = require('../utils/formatPlayer');

module.exports = (app) => {

	app.get('/staff', async (req, res) => {

		const staffRanks = await Rank.find({ isStaff: true }).sort({ order: 1 });
		const staffRankNames = staffRanks.map((rank) => rank.name);

		const staffRanksObj = {};
		
		for (const staffRank of staffRanks) {
			staffRanksObj[staffRank.name] = await staffRank.format();
			staffRanksObj[staffRank.name].players = {};
		}

		const players = await getPlayers();
		for (const player of players) {
			const playerRanks = await getPlayerRanks(player.uuid);
			if (playerRanks) {
				for (const rank of playerRanks) {
					if (staffRankNames.includes(rank.name)) {
						const staffRank = staffRanks.find((_rank) => _rank.name === rank.name);
						if (staffRank) {
							if (!(player.uuid in staffRanksObj[rank.name].players)) {
								const formattedPlayer = await formatPlayer(player);
								staffRanksObj[rank.name].players[player.uuid] = formattedPlayer;
							}
						}
					}
				}
			}
		}

		res.context.page = 'staff';
		res.context.title = 'Staff';

		res.context.staffRanks = staffRanksObj;

		res.render('staff');

	});

}
