const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const Notification = require('../models/Notification');
const Ticket = require('../models/Ticket');
const TicketCategory = require('../models/TicketCategory');
const TicketReply = require('../models/TicketReply');

module.exports = (app) => {

	app.get('/tickets', authMiddleware, async (req, res) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;
		
		const tickets = await Ticket.find({ author: req.authenticatedUser.id }).sort({ createdAt: 1 });
		tickets.sort((a, b) => a.status === 1 ? -1 : 0);
		tickets.sort((a, b) => a.status === 2 ? -1 : 0);
		tickets.sort((a, b) => a.status === 0 ? -1 : 0);

		const ticketsPagination = paginate(tickets, currentPage, 15, `?page={x}`);
		const formattedTickets = [];

		for (const ticket of ticketsPagination.items) {

			const replies = await TicketReply.find({ ticket: ticket.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;
			
			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedTicket = await ticket.format();
			formattedTicket.repliesCount = repliesCount;
			formattedTicket.latestReply = formattedLatestReply;

			formattedTickets.push(formattedTicket);

		}

		res.context.page = 'tickets';
		res.context.title = 'Tickets';

		res.context.tickets = formattedTickets;
		res.context.pagination = ticketsPagination.nav;

		res.render('tickets');

	});

	app.get('/ticket/new/:slug', authMiddleware, async (req, res) => {

		const ticketCategorySlug = req.params.slug;

		const ticketCategory = await TicketCategory.findOne({ slug: ticketCategorySlug }) ;
		if (!ticketCategory) {
			return res.throw404();
		}

		const formattedTicketCategory = await ticketCategory.format();

		res.context.page = 'tickets.new';
		res.context.title = 'New Ticket';

		res.context.ticketCategory = formattedTicketCategory;

		res.render('ticket.new');

	});

	app.post('/ticket/new', csrfMiddleware, authMiddleware, async (req, res) => {

		const categoryId = req.body.category;
		const { content } = req.body;

		let ticketCategory = null;
		try {
			ticketCategory = await TicketCategory.findById(categoryId);
		} catch (error) { }

		if (!ticketCategory) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:4096',
		})) { return };

		const ticket = await Ticket.create({
			category: ticketCategory.id,
			subcategory: ticketCategory.subcategories && ticketCategory.subcategories.length > 0 ? subcategory : null,
			author: req.authenticatedUser.id,
			content
		});

		req.flash('successMessage', 'The ticket has been successfully created.');
		res.redirect(`/ticket/${ticket.fid}`);

	});

	app.post('/ticket/close', csrfMiddleware, authMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (ticket.status !== 0) {
			return res.redirect(req.referer);
		}

		if (ticket.author !== req.authenticatedUser.id) {
			return res.throw404();
		}

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 2
		});

		if (ticket.author !== req.authenticatedUser.id) { 
			Notification.create({
				user: ticket.author,
				title: 'Ticket Closed',
				content: `${req.authenticatedUser.name} has closed your ticket.`,
				link: `/ticket/${ticket.fid}`
			});
		}

		req.flash('successMessage', 'The ticket has been successfully closed.');
		res.redirect(req.referer);

	});

	app.post('/ticket/reply', csrfMiddleware, authMiddleware, async (req, res) => {

		const ticketId = req.body.ticket;
		const { content } = req.body;
		
		let ticket = null;
		try {
			ticket = await Ticket.findById(ticketId);
		} catch (err) { }

		if (!ticket) {
			return res.redirect(req.referer);
		}

		if (ticket.author !== req.authenticatedUser.id) {
			return res.throw404();
		}
		
		if (!await req.validateInput({
			content: 'required|minLength:1|maxLength:1024'
		})) { return };

		await TicketReply.create({
			author: req.authenticatedUser.id,
			ticket: ticket.id,
			content
		});

		await Ticket.findByIdAndUpdate(ticket.id, {
			status: 0
		});

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});
	
	app.get('/ticket/:id', authMiddleware, async (req, res) => {

		const ticketId = req.params.id;

		let ticket = null;
		try {
			ticket = await Ticket.findOne({ fid: ticketId });
		} catch (err) { }

		if (!ticket) {
			return res.throw404();
		}

		if (ticket.author !== req.authenticatedUser.id) {
			return res.throw404();
		}

		const ticketCategory = await TicketCategory.findById(ticket.category);
		if (!ticketCategory) {
			return res.throw404();
		}

		const ticketReplies = await TicketReply.find({ ticket: ticket.id }).sort({ createdAt: 1 });
		const formattedTicketReplies = [];

		for (const reply of ticketReplies) {
			const formattedReply = await reply.format();
			formattedReply.isManageable = await reply.isManageableBy(req.authenticatedUser);
			formattedTicketReplies.push(formattedReply);
		}
		

		const formattedTicket = await ticket.format();
		formattedTicket.isManageable = await ticket.isManageableBy(req.authenticatedUser);
		formattedTicket.replies = formattedTicketReplies;

		res.context.page = 'ticket';
		res.context.title = `Ticket #${ticket.fid}`;
		
		res.context.ticket = formattedTicket;

		res.render('ticket');

	});

}