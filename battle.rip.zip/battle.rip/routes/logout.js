module.exports = (app) => {

	app.get('/logout', async (req, res) => {

		if (!req.isUserAuthenticated) {
			return res.redirect('/');
		}

		req.session.authenticatedUser = null;
		res.redirect(req.referer);

	});

}