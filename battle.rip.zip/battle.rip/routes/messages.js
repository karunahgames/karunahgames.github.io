const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const DirectMessage = require('../models/DirectMessage');
const DirectMessageReply = require('../models/DirectMessageReply');
const Notification = require('../models/Notification');
const User = require('../models/User');

module.exports = (app) => {

	app.get('/messages', authMiddleware, async (req, res) => {

		const messages = await DirectMessage.find({
			$or: [
				{ author: req.authenticatedUser.id },
				{ recipient: req.authenticatedUser.id }
			]
		}).sort({ createdAt: -1 });

		const formattedMessages = [];
		for (const message of messages) {

			const replies = await DirectMessageReply.find({ message: message.id }).sort({ createdAt: 1 });
			const repliesCount = replies.length;

			const latestReply = replies.length ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedMessage = await message.format();
			formattedMessage.repliesCount = repliesCount;
			formattedMessage.latestReply = formattedLatestReply;
			
			formattedMessages.push(formattedMessage);

		}

		res.context.page = 'messages';
		res.context.title = 'Messages';

		res.context.messages = formattedMessages;

		res.render('messages');

	});

	app.get('/message/new/:recipient?', authMiddleware, async (req, res) => {

		const recipientUsername = req.params.recipient;

		let recipient = null;
		if (recipientUsername) {
			recipient = await User.findOne({ name: { $regex : new RegExp(recipientUsername, 'i') } });
		}

		const formattedRecipient = await recipient?.format();

		res.context.page = 'message.new';
		res.context.title = 'New Message';
		
		res.context.recipient = formattedRecipient;
		
		res.render('message.new');
		
	});

	app.post('/message/new', csrfMiddleware, authMiddleware, async (req, res) => {

		const { title, content, recipient: recipientUsername } = req.body;

		const recipient = await User.findOne({ name: { $regex : new RegExp(recipientUsername, 'i') } });
		if (!recipient) {
			req.flash('errorMessage', 'Couldn\'t find the specified recipient.');
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			title: 'required|minLength:3|maxLength:64',
			content: 'required|minLength:3|maxLength:4096',
		})) { return };

		if (req.authenticatedUser.id === recipient.id) {
			req.flash('errorMessage', 'You cannot send yourself a message.');
			return res.redirect(req.referer);
		}

		const message = await DirectMessage.create({
			title,
			content,
			author: req.authenticatedUser.id,
			recipient: recipient.id
		});

		Notification.create({
			user: recipient.id,
			title: 'Direct Message',
			content: `${req.authenticatedUser.id} has sent you a direct message.`,
			link: `/message/${message.fid}`
		});

		req.flash('successMessage', 'The message has been successfully created.');
		res.redirect(`/message/${message.fid}`);

	});

	app.post('/message/reply', csrfMiddleware, authMiddleware, async (req, res) => {
		
		const messageId = req.body.message;
		const { content } = req.body;

		let message = null;
		try {
			message = await DirectMessage.findById(messageId);
		} catch (err) { }

		if (!message) {
			return res.redirect(req.referer);
		}

		const author = await User.findById(message.author);
		const recipient = await User.findById(message.recipient);

		if (req.authenticatedUser.id !== author.id && req.authenticatedUser.id !== recipient.id) {
			return res.redirect(req.referer);
		}

		if (!await req.validateInput({
			content: 'required|minLength:3|maxLength:1024'
		})) { return };

		await DirectMessageReply.create({
			author: req.authenticatedUser.id,
			message: message.id,
			content
		});

		Notification.create({
			user: (req.authenticatedUser.id === message.author ? message.recipient : message.author),
			title: 'Direct Message',
			content: `${req.authenticatedUser.name} has replied to the direct message.`,
			link: `/message/${message.fid}`
		});

		req.flash('successMessage', 'The reply has been successfully created.');
		res.redirect(req.referer);

	});

	app.post('/message/reply/delete', csrfMiddleware, authMiddleware, async (req, res) => {

		const replyId = req.body.reply;

		let messageReply = null;
		try {
			messageReply = await DirectMessageReply.findById(replyId);
		} catch (err) { }

		if (!messageReply) {
			return res.redirect(req.referer);
		}

		if (!await messageReply.isManageableBy(req.authenticatedUser)) {
			return res.redirect(req.referer);
		}

		await DirectMessageReply.findByIdAndDelete(messageReply.id);

		req.flash('successMessage', 'The reply has been successfully deleted.');
		res.redirect(req.referer);

	});

	app.get('/message/:id', authMiddleware, async (req, res) => {

		const messageId = req.params.id;

		let message = null;
		try {
			message = await DirectMessage.findOne({ fid: messageId });
		} catch (err) { }

		if (!message) {
			return res.throw404();
		}

		const author = await User.findById(message.author);
		const recipient = await User.findById(message.recipient);

		if (req.authenticatedUser.id !== author.id && req.authenticatedUser.id !== recipient.id) {
			return res.redirect(req.referer);
		}

		const messageReplies = await DirectMessageReply.find({ message: message.id });
		const formattedMessageReplies = [];

		for (const messageReply of messageReplies) {
			const formattedMessageReply = await messageReply.format();
			formattedMessageReply.isManageable = await messageReply.isManageableBy(req.authenticatedUser);
			formattedMessageReplies.push(formattedMessageReply);
		}

		const formattedMessage = await message.format();
		formattedMessage.replies = formattedMessageReplies;
		formattedMessage.isManageable = await message.isManageableBy(req.authenticatedUser);

		res.context.page = 'messages';
		res.context.title = message.title;
		
		res.context.message = formattedMessage;
		
		res.render('message');

	});

}