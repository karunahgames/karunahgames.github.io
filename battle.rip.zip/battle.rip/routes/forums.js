const paginate = require('../utils/paginate');
const Forum = require('../models/Forum');
const ForumCategory = require('../models/ForumCategory');
const Thread = require('../models/Thread');
const ThreadReply = require('../models/ThreadReply');

module.exports = (app) => {

	app.get('/forums', async (req, res) => {

		const forums = await Forum.find().sort({ order: 1 });
		const forumCategories = await ForumCategory.find().sort({ order: 1 });

		const formattedForumCategories = [];

		for (const forumCategory of forumCategories) {

			const filteredForums = forums.filter((forum) => forum.category === forumCategory.id);
			const formattedFilteredForums = [];

			for (const forum of filteredForums) {

				const threads = await Thread.find({ forum: forum.id }).sort({ createdAt: 1 });
				const threadsCount = threads.length;

				const latestThread = threads.length ? threads[threads.length - 1] : null;
				const formattedLatestThread = await latestThread?.format();

				const formattedForum = await forum.format();
				formattedForum.threadsCount = threadsCount;
				formattedForum.latestThread = formattedLatestThread;
				
				formattedFilteredForums.push(formattedForum);

			}

			const formattedForumCategory = await forumCategory.format();
			formattedForumCategory.forums = formattedFilteredForums;

			formattedForumCategories.push(formattedForumCategory);

		}
		
		res.context.page = 'forums';
		res.context.title = 'Forums';
		
		res.context.forumCategories = formattedForumCategories;

		res.render('forums');

	});

	app.get('/forums/:slug', async (req, res) => {

		const currentPage = req.query.page ? parseInt(req.query.page) : 1;

		const forumSlug = req.params.slug;

		const forum = await Forum.findOne({ slug: forumSlug });
		if (!forum) {
			return res.throwError(404);
		}

		if (forum.redirectUrl) {
			res.redirect(forum.redirectUrl);
			return;
		}

		const threads = await Thread.find({ forum: forum.id }).sort({ createdAt: -1 });

		threads.sort((a, b) => {
			return b.isPinned - a.isPinned;
		});

		const threadsPagination = paginate(threads, currentPage, 15, `?page={x}`);

		const formattedThreads = [];
		for (const thread of threadsPagination.items) {

			const upvotes = thread.upvotes;
			const upvotesCount = upvotes.length;
			
			const replies = await ThreadReply.find({ thread: thread.id, parent: null }).sort({ createdAt: 1 });
			const repliesCount = replies.length;
			
			const latestReply = replies.last ? replies[replies.length - 1] : null;
			const formattedLatestReply = await latestReply?.format();

			const formattedThread = await thread.format();
			formattedThread.upvotesCount = upvotesCount;
			formattedThread.repliesCount = repliesCount;
			formattedThread.latestReply = formattedLatestReply;

			formattedThreads.push(formattedThread);

		}
		
		const formattedForum = await forum.format();
		formattedForum.threads = formattedThreads;
		
		res.context.page = 'forums';
		res.context.title = forum.name;

		res.context.forum = formattedForum;
		res.context.pagination = threadsPagination.nav;
		// res.context.currentSort = currentSort;
		
		res.render('forums.view');

	});

}