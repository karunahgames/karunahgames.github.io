const bcrypt = require('bcrypt');
const User = require('../models/User');
const getPlayer = require('../utils/getPlayer');
const getPlayerInfo = require('../utils/getPlayerInfo');

module.exports = (app) => {

	app.get('/login', (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(res.referer);
		}

		res.context.page = 'login';
		res.context.title = 'Login';

		res.render('login');

	});

	app.post('/login', async (req, res) => {

		if (req.isUserAuthenticated) {
			return res.redirect(res.referer);
		}

		const { username, password } = req.body;

		if (!await req.validateInput({
			username: 'required|minLength:3|maxLength:16',
			password: 'required'
		})) { return };
		
		// const playerInfo = await getPlayerInfo(username);
		// if (!playerInfo) {
		// 	req.flash('errorMessage', 'Could not find an account with that username.');
		// 	return res.redirect(req.referer);
		// }

		// const player = await getPlayer(playerInfo.uuid);
		// if (!player) {
		// 	req.flash('errorMessage', 'Could not find an account with that username.');
		// 	return res.redirect(req.referer);
		// }

		const user = await User.findOne({ name: username });
		if (!user) {
			req.flash('errorMessage', 'That account is not registered.');
			return res.redirect(req.referer);
		}

		if (!user.isActive) {
			req.flash('errorMessage', 'That account is not active.');
			return res.redirect(req.referer);
		}

		const isPasswordValid = await bcrypt.compare(password, user.password);
		if (!isPasswordValid) {
			req.flash('errorMessage', 'The password for that account is invalid.');
			return res.redirect(req.referer);
		}

		// if (playerInfo.name !== user.name) {
		// 	await User.findByIdAndUpdate(user.id, { name: playerInfo.name });
		// }

		req.session.authenticatedUser = user.id;

		res.redirect(req.query.next || '/');

	});

}