const UhcGame = require('../models/UhcGame');
const formatMatch = require('../utils/formatMatch');
const getMatch = require('../utils/getMatch');
const getMatches = require('../utils/getMatches');

module.exports = (app) => {

	app.get('/matches', async (req, res) => {

		const currentDate = new Date();

		const upcomingGames = await UhcGame.find({ status: 1, openingAt: { $gte: currentDate } }).sort({ openingAt: 1 });
		const formattedUpcomingGames = await Promise.all(upcomingGames.map((game) => game.format()));

		const pastMatches = await getMatches();
		const slicedPastMatches = pastMatches.slice(pastMatches.length - 10, pastMatches.length);
		const formattedPastMatches = await Promise.all(slicedPastMatches.map((match) => formatMatch(match)));

		res.context.page = 'games';
		res.context.title = 'UHC Games';
		res.context.upcomingGames = formattedUpcomingGames;
		res.context.pastMatches = formattedPastMatches;
		res.render('matches');

	});

	app.get('/match/:id', async (req, res) => {

		const matchId = req.params.id;

		const match = await getMatch(matchId);
		if (!match) {
			return res.throw404();
		}

		const formattedMatch = await formatMatch(match);

		res.context.page = 'games';
		res.context.title = 'UHC Games';
		res.context.match = formattedMatch;
		res.render('match');

	});


}