const bcrypt = require('bcrypt');
const authMiddleware = require('../middlewares/auth');
const csrfMiddleware = require('../middlewares/csrf');
const User = require('../models/User');

module.exports = (app) => {

	app.get('/account', authMiddleware, async (req, res) => {

		res.context.page = 'account';
		res.context.title = 'Account';
		
		res.render('account');

	});

	app.post('/account/change-socials', csrfMiddleware, authMiddleware, async (req, res) => {

		const socials = {};

		const socialKeys = ['youtube', 'twitter', 'twitch', 'steam', 'reddit', 'github', 'telegram', 'discord'];
		for (const key of socialKeys) {
			socials[key] = req.body[key] || '';
		}

		await User.findByIdAndUpdate(req.authenticatedUser.id, { socials });

		req.flash('successMessage', 'The socials have been successfully updated.');
		res.redirect(req.referer);

	});

	app.post('/account/change-email', csrfMiddleware, authMiddleware, async (req, res) => {

		const { currentPassword, newEmail } = req.body;

		if (!await req.validateInput({
			currentPassword: 'required',
			newEmail: 'required|email'
		})) { return };

		const user = req.authenticatedUser;

		const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
		if (!isPasswordValid) {
			req.flash('errorMessage', 'The current password is invalid.');
			return res.redirect(req.referer);
		}

		await User.findByIdAndUpdate(user.id, { email: newEmail });

		req.flash('successMessage', 'The email has been successfully updated.');
		res.redirect(req.referer);

	});

	app.post('/account/change-password', csrfMiddleware, authMiddleware, async (req, res) => {

		const { currentPassword, newPassword, confirmNewPassword } = req.body;

		if (!await req.validateInput({
			currentPassword: 'required',
			newPassword: 'required|minLength:3|maxLength:32',
			confirmNewPassword: 'required|same:newPassword'
		})) { return };

		const user = req.authenticatedUser;

		const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
		if (!isPasswordValid) {
			req.flash('errorMessage', 'The current password is invalid.');
			return res.redirect(req.referer);
		}

		const salt = await bcrypt.genSalt(10);
		const hashedPassword = await bcrypt.hash(newPassword, salt);

		await User.findByIdAndUpdate(user.id, { password: hashedPassword });

		req.flash('successMessage', 'The password has been successfully updated.');
		res.redirect(req.referer);

	});

}