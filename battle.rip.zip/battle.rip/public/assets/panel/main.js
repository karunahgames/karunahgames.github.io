/*
 *	MADE BY XEMAH
 *	https://xemah.com
 *
 *
**/

document.addEventListener('submit', (event) => {

	const form = event.target;

	if (form.method.toLowerCase() !== 'post') {
		return;
	}

	if (form._csrftoken !== undefined) {
		return;
	}

	const tokenInput = document.createElement('input');
	tokenInput.type = 'hidden';
	tokenInput.name = '_csrftoken';
	tokenInput.value = csrfToken;
	form.appendChild(tokenInput);

	const submitButton = form.querySelector('button[type="submit"]');
	if (submitButton) {
		submitButton.disabled = true;
	}

});

/*!
* Start Bootstrap - SB Admin v7.0.4 (https://startbootstrap.com/template/sb-admin)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
*/
// 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
            document.body.classList.toggle('sb-sidenav-toggled');
        }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});