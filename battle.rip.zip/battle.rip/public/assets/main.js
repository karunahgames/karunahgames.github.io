/*
 *	MADE BY XEMAH
 *	https://xemah.com
 *
 *
**/

var currentPath = location.pathname.replace(/\/$/, '') + location.search;

function findAncestor(el, sel) {

	if ((el.matches || el.matchesSelector).call(el, sel)) {
		return el;
	}

	while ((el = el.parentElement) && !((el.matches || el.matchesSelector).call(el, sel)));
	return el;

}

function copy(event, elementSelector, successMessage) {
	
	event.preventDefault();

	let element = document.querySelector(elementSelector);
	let temp = document.createElement('input');
	document.body.append(temp);
	temp.value = element.textContent;
	temp.select();
	document.execCommand('copy');
	temp.remove();
	alert(successMessage);

}

(() => {

	const dropdownElementList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'));
	dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
		return new bootstrap.Dropdown(dropdownToggleEl, { /*autoClose: 'outside'*/ });
	});

})();

(() => {

	const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
	tooltipTriggerList.map(function (tooltipTriggerEl) {
		return new bootstrap.Tooltip(tooltipTriggerEl);
	});

})();

(() => {

	const imageElements = document.querySelectorAll('img');
	for (const element of imageElements) {
		element.addEventListener('error', () => {
			element.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';
		});
	}

})();

(() => {

	const minecraftPlayersCount = document.querySelectorAll('[data-count="minecraft-players"]');
	for (const element of minecraftPlayersCount) {

		const serverIp = element.dataset.ip.split(':')[0];
		const serverPort = element.dataset.ip.split(':')[1] ?? '25565';

		fetch(`https://mcapi.us/server/status?ip=${serverIp}&port=${serverPort}`)
			.then((res) => res.json())
			.then((data) => {
				element.innerHTML = data.online ? data.players.now : 0;
			});

	}

})();

(() => {

	const discordUsersCount = document.querySelectorAll('[data-count="discord-users"]');
	for (const element of discordUsersCount) {

		fetch(`https://discordapp.com/api/servers/${element.dataset.id}/widget.json`)
			.then((res) => res.json())
			.then((data) => {
				element.innerHTML = data.presence_count ? data.presence_count : 0;
			});

	}

})();

(() => {

	document.addEventListener('submit', (event) => {

		const form = event.target;
		if (form.method.toLowerCase() !== 'post') {
			return;
		}

		if (form._csrftoken !== undefined) {
			return;
		}

		const tokenInput = document.createElement('input');
		tokenInput.type = 'hidden';
		tokenInput.name = '_csrftoken';
		tokenInput.value = csrfToken;
		form.appendChild(tokenInput);

		const submitButton = form.querySelector('button[type="submit"]');
		if (submitButton && submitButton.dataset.disable != 'false') {
			submitButton.disabled = true;
		}

	});

})();

(() => {

	document.addEventListener('click', (event) => {

		const anchor = findAncestor(event.target, '[data-href]');
		if (!anchor) {
			return;
		}

		const anchorHref = anchor.dataset.href;
		if (!anchorHref) {
			return;
		}

		window.location.href = anchorHref;

	});

})();

(() => {

	const playerSearchInput = document.querySelector('#input-playerSearch');
	if (!playerSearchInput) {
		return false;
	}

	const playerSearchDropdown = document.querySelector('#dropdown-playerSearch');
	const playerSearchDropdownToggler = playerSearchDropdown.querySelector('[data-bs-toggle="dropdown"]');
	const playerSearchDropdownMenu = playerSearchDropdown.querySelector('.dropdown-menu');

	let playerSearchDropdownInstance = bootstrap.Dropdown.getInstance(playerSearchDropdownToggler);
	if (!playerSearchDropdownInstance) {
		playerSearchDropdownInstance = new bootstrap.Dropdown(playerSearchDropdownToggler);
	}

	playerSearchDropdown.addEventListener('show.bs.dropdown', (event) => {
		if (playerSearchDropdownMenu && playerSearchDropdownMenu.innerHTML.trim() == '') {
			event.preventDefault();
		}
	});

	let playerSearchTimeout = null;

	playerSearchInput.addEventListener('input', () => {

		playerSearchDropdownInstance.hide();

		if (playerSearchInput.value.length > 2) {
			
			if (playerSearchTimeout) {
				clearTimeout(playerSearchTimeout);
			}

			playerSearchTimeout = setTimeout(async () => {

				const response = await fetch(`/search/${playerSearchInput.value}`);
				if (!response) {
					return false;
				}

				const responseJson = await response.json();
				const responseData = responseJson.data;

				const users = responseData.users || [];

				playerSearchDropdownMenu.innerHTML = users.map((user) => {
					return `<li>
						<a href="${user.link}" class="dropdown-item">
							<img src="${user.avatar.face}" alt="${user.name}">
							<span>${user.name}</span>
						</a>
					</li>`;
				}).join('');

				if (users.length > 0) {
					playerSearchDropdownInstance.show();
				}

			}, 1000);
			
		}

	});

})();

(() => {

	document.addEventListener('submit', (event) => {

		const form = event.target;
		const formAction = form.getAttribute('action');

		if (!formAction.startsWith('/thread') || !formAction.endsWith('/upvote')) {
			return;
		}

		event.preventDefault();

		const submitButton = form.querySelector('button[type="submit"]');
		const countElement = submitButton.querySelector('.count');

		const currentUpvotes = parseInt(countElement.innerHTML) || 0;

		if (submitButton.classList.contains('active')) {
			const newUpvotes = currentUpvotes - 1;
			submitButton.classList.remove('active');
			countElement.innerHTML = newUpvotes;
		} else {
			const newUpvotes = currentUpvotes + 1;
			submitButton.classList.add('active');
			countElement.innerHTML = newUpvotes;
		}

		fetch(form.action, {
			method: 'POST',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(Object.fromEntries(new FormData(form)))
		});

	});

	// const upvoteForms = document.querySelectorAll('form[action^="/thread"][action$="/upvote"]');
	// for (const form of upvoteForms) {

	// 	form.addEventListener('submit', (event) => {

	// 		event.preventDefault();
			
	// 		const submitButton = form.querySelector('button[type="submit"]');
	// 		const countElement = submitButton.querySelector('.count');

	// 		const currentUpvotes = parseInt(countElement.innerHTML);

	// 		if (submitButton.classList.contains('upvoted')) {
	// 			const newUpvotes = currentUpvotes - 1;
	// 			submitButton.classList.remove('upvoted');
	// 			countElement.innerHTML = newUpvotes;
	// 		} else {
	// 			const newUpvotes = currentUpvotes + 1;
	// 			submitButton.classList.add('upvoted');
	// 			countElement.innerHTML = newUpvotes;
	// 		}

	// 		const formData = new FormData(form);

	// 		fetch(form.action, {
	// 			method: 'POST',
	// 			headers: {
	// 				'Accept': 'application/json',
	// 				'Content-Type': 'application/json'
	// 			},
	// 			body: JSON.stringify(Object.fromEntries(formData))

	// 		});

	// 	});

	// }

})();


// const loadPage = async (href, pushToHistory = false) => {
	
// 	const newLocation = new URL(href);
	
// 	const newPath = newLocation.pathname.replace(/\/$/, '') + newLocation.search;
// 	if (newPath === currentPath) {
// 		return;
// 	}

// 	document.documentElement.classList.remove('loaded');
// 	window.stop();
	
// 	const response = await fetch(newLocation.href);
// 	if (!response) {
// 		return;
// 	}

// 	const responseText = await response.text();
// 	if (!responseText) {
// 		return;
// 	}

// 	const domParser = new DOMParser();
// 	const newDocument = domParser.parseFromString(responseText, 'text/html');
// 	if (!newDocument) {
// 		return;
// 	}

// 	if (pushToHistory) {
// 		window.history.pushState({ }, null, newLocation.href);
// 	}

// 	document.documentElement.style.scrollBehavior = 'auto';

// 	setTimeout(() => window.scrollTo(0, 0), 5);
// 	setTimeout(() => document.documentElement.style.removeProperty('scroll-behavior'), 5);

// 	document.title = newDocument.title;
	
// 	for (const block of ['#block-header-banner', '#block-content']) {

// 		const newBlock = newDocument.querySelector(block);
// 		if (!newBlock) {
// 			return;
// 		}

// 		const currentBlock = document.querySelector(block);
// 		if (!currentBlock) {
// 			return;
// 		}

// 		currentBlock.innerHTML = newBlock.innerHTML;

// 	}

// 	document.documentElement.classList.add('loaded');

// 	currentPath = newLocation.pathname.replace(/\/$/, '') + newLocation.search;

// }

// document.addEventListener('click', (event) => {

// 	const anchor = findAncestor(event.target, 'a');
// 	if (!anchor) {
// 		return;
// 	}

// 	const anchorLocation = new URL(anchor.href);

// 	if (anchorLocation.origin !== location.origin) {
// 		return;
// 	}

// 	if (anchorLocation.pathname === location.pathname && anchorLocation.hash !== location.hash) {
// 		return;
// 	}

// 	event.preventDefault();
// 	loadPage(anchorLocation.href, true);

// });

// window.addEventListener('popstate', (event) => {

// 	loadPage(location.href);

// });