const mongoose = require('mongoose');
const slugify = require('../utils/slugify');
const Forum = require('./Forum');
const User = require('./User');
const generateId = require('../utils/generateId');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	forum: {
		type: String,
		required: true
	},
	views: {
		type: Number,
		default: 0
	},
	upvotes: {
		type: Array,
		default: []
	},
	isPinned: {
		type: Boolean,
		default: false
	},
	isFeatured: {
		type: Boolean,
		default: false
	},
	editedAt: {
		type: Date,
		default: null
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const forum = await Forum.findById(this.forum);
	const formattedForum = await forum?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		fid: this.fid,
		title: this.title,
		content: this.content,
		parsedContent: parsedContent,
		link: `/thread/${this.fid}/${slugify(this.title)}`,
		author: formattedAuthor,
		forum: formattedForum,
		views: this.views,
		upvotes: this.upvotes,
		isPinned: Boolean(this.isPinned),
		isFeatured: Boolean(this.isFeatured),
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt),
		editedAt: formatTime(this.editedAt),
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('Thread', schema);