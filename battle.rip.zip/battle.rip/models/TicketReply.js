const mongoose = require('mongoose');
const Ticket = require('./Ticket');
const User = require('./User');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	author: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	ticket: {
		type: String,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const ticket = await Ticket.findById(this.ticket);
	const formattedTicket = await ticket?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		ticket: formattedTicket,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('TicketReply', schema);