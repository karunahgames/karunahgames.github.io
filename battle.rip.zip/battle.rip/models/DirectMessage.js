const mongoose = require('mongoose');
const User = require('./User');
const generateId = require('../utils/generateId');
const formatTime = require('../utils/formatTime');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	recipient: {
		type: String,
		required: true
	},
	editedAt: {
		type: Date,
		default: null
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();

	const recipient = await User.findById(this.recipient);
	const formattedRecipient = await recipient?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent);

	return {
		id: this.id,
		fid: this.fid,
		title: this.title,
		link: `/message/${this.fid}`,
		author: formattedAuthor,
		recipient: formattedRecipient,
		content: this.content,
		parsedContent: parsedContent,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt),
		editedAt: formatTime(this.editedAt)
	};
	
};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}
	
	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('DirectMessage', schema);