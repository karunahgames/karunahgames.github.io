const mongoose = require('mongoose');
const User = require('./User');
const ProfilePost = require('./ProfilePost');
// const encodeString = require('../utils/encodeString');
// const parseMarkdown = require('../utils/parseMarkdown');
// const censorBadWords = require('../utils/censorBadWords');

const schema = new mongoose.Schema({
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	post: {
		type: String,
		required: true
	},
	editedAt: {
		type: Date,
		default: null
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const profilePost = await ProfilePost.findById(this.post);
	const formattedPost = await profilePost?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	// parsedContent = await encodeString(this.content);
	// parsedContent = await parseMarkdown(parsedContent, true);
	// parsedContent = await censorBadWords(parsedContent);

	return {
		id: this.id,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		post: formattedPost,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt),
		editedAt: formatTime(this.editedAt),
	};
	
};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('ProfilePostReply', schema);