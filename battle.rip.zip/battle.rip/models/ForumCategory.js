const mongoose = require('mongoose');

const schema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	order: {
		type: Number,
		default: 5
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	return {
		id: this.id,
		name: this.name,
		order: this.order
	};

};

module.exports = mongoose.model('ForumCategory', schema);