const mongoose = require('mongoose');
const crypto = require('crypto');
const formatTime = require('../utils/formatTime');
const formatPlayer = require('../utils/formatPlayer');

const schema = new mongoose.Schema({
	uuid: {
		type: String,
		required: true
	},
	name: {
		type: String,
		required: true
	},
	email: {
		type: String,
		required: true
	},
	code: {
		type: String,
		default: () => crypto.randomBytes(64).toString('hex')
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	let player = await getPlayer(this.uuid);
	if (!player) {
		player = { uuid: this.uuid, name: this.name }
	}

	const formattedPlayer = await formatPlayer(player);

	return {
		id: this.id,
		player: formattedPlayer,
		name: this.name,
		email: this.email,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};
	
};

module.exports = mongoose.model('UserRegistration', schema);