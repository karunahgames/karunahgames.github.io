const mongoose = require('mongoose');
const ApplicationCategory = require('./ApplicationCategory');
const User = require('./User');
const generateId = require('../utils/generateId');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	category: {
		type: String,
		required: true
	},
	qna: {
		type: Array,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	status: {
		type: Number,
		default: 0 // 0 = Open, 1 = Accepted, 2 = Rejected
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const applicationCategory = await ApplicationCategory.findById(this.category);
	const formattedApplicationCategory = await applicationCategory?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();

	return {
		id: this.id,
		fid: this.fid,
		category: formattedApplicationCategory,
		subcategory: this.subcategory,
		qna: this.qna,
		link: `/application/${this.fid}`,
		status: this.status,
		author: formattedAuthor,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	const applicationCategory = await ApplicationCategory.findById(this.category);
	if (!applicationCategory) {
		return false;
	}
	
	if (await user.hasAnyRank(applicationCategory.moderationRanks)) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('Application', schema);