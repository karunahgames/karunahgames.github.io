const mongoose = require('mongoose');

const schema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	title: {
		type: String,
		required: true
	},
	color: {
		type: String,
		default: '#808080'
	},
	order: {
		type: Number,
		default: 5
	},
	isDonator: {
		type: Boolean,
		default: false
	},
	isMedia: {
		type: Boolean,
		default: false
	},
	isStaff: {
		type: Boolean,
		default: false
	},
	isModeration: {
		type: Boolean,
		default: false
	},
	isAdministration: {
		type: Boolean,
		default: false
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	return {
		id: this.id,
		name: this.name,
		title: this.title,
		color: this.color,
		order: this.order,
		isDonator: Boolean(this.isDonator),
		isMedia: Boolean(this.isMedia),
		isStaff: Boolean(this.isStaff),
		isModeration: Boolean(this.isModeration),
		isAdministration: Boolean(this.isAdministration)
	};
	
};

module.exports = mongoose.model('Rank', schema);