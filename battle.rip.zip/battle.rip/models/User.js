const mongoose = require('mongoose');
const getPlayer = require('../utils/getPlayer');
const getPlayerRanks = require('../utils/getPlayerRanks');
const formatPlayer = require('../utils/formatPlayer');
const config = require('../config.json');

const schema = new mongoose.Schema({
	uuid: {
		type: String,
		required: true
	},
	name: {
		type: String,
		required: true
	},
	email: {
		type: String,
		required: true
	},
	password: {
		type: String,
		required: true
	},
	socials: {
		type: Object,
		default: { }
	},
	isActive: {
		type: Boolean,
		default: false
	},
	isBanned: {
		type: Boolean,
		default: false
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	let player = await getPlayer(this.uuid);
	if (player) {
		player.name = this.name;
	} else {
		player = { uuid: this.uuid, name: this.name };
	}

	const formattedPlayer = await formatPlayer(player);

	return {
		id: this.id,
		...formattedPlayer,
		socials: this.socials,
		isActive: Boolean(this.isActive),
		isBanned: Boolean(this.isBanned),
		isStaff: await this.isStaff(),
		hasModPermission: await this.hasModPermission(),
		hasAdminPermission: await this.hasAdminPermission(),
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};
	
};

schema.methods.getRanks = async function() {

	const playerRanks = await getPlayerRanks(this.uuid);
	return playerRanks;

};

schema.methods.hasRank = async function(rankName) {

	const playerRanks = await getPlayerRanks(this.uuid);
	if (playerRanks.find((rank) => rank.name === rankName)) {
		return true;
	}

	return false;

};

schema.methods.hasAnyRank = async function(rankNamesOrIds) {

	const playerRanks = await getPlayerRanks(this.uuid);
	if (playerRanks.find((rank) => rankNamesOrIds.includes(rank.id) || rankNamesOrIds.includes(rank.name))) {
		return true;
	}

	return false;

};

schema.methods.isStaff = async function() {

	if (config.superUsers && config.superUsers.includes(this.name)) {
		return true;
	}

	const userRanks = await this.getRanks();
	
	const isStaff = userRanks.some((rank) => rank.isStaff);
	return isStaff;

};

schema.methods.hasModPermission = async function() {

	if (config.superUsers && config.superUsers.includes(this.name)) {
		return true;
	}

	const userRanks = await this.getRanks();

	const hasModPermission = userRanks.some((rank) => rank.isModeration);
	return hasModPermission;

};

schema.methods.hasAdminPermission = async function() {

	if (config.superUsers && config.superUsers.includes(this.name)) {
		return true;
	}

	const userRanks = await this.getRanks();

	const hasAdminPermission = userRanks.some((rank) => rank.isAdministration);
	return hasAdminPermission;

};

module.exports = mongoose.model('User', schema);