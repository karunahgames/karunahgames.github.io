const mongoose = require('mongoose');
const Rank = require('./Rank');

const schema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	description: {
		type: String,
		default: ''
	},
	slug: {
		type: String,
		required: true
	},
	order: {
		type: Number,
		default: 5
	},
	moderationRanks: {
		type: Array,
		default: []
	},
	questions: {
		type: String,
		default: ''
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const moderationRanks = [];
	for (const rankId of this.moderationRanks) {
		const rank = await Rank.findById(rankId);
		if (rank) {
			const formattedRank = await rank.format();
			moderationRanks.push(formattedRank);
		}
	}

	let parsedQuestions = [];
	try {
		parsedQuestions = JSON.parse(this.questions);
	} catch (err) { }

	return {
		id: this.id,
		name: this.name,
		description: this.description,
		slug: this.slug,
		order: this.order,
		moderationRanks: moderationRanks,
		questions: this.questions,
		parsedQuestions: parsedQuestions
	};

};

module.exports = mongoose.model('ApplicationCategory', schema);