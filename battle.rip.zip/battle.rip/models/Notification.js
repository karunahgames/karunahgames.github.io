const mongoose = require('mongoose');
const User = require('./User');
const generateId = require('../utils/generateId');
const formatTime = require('../utils/formatTime');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	link: {
		type: String,
		required: true
	},
	user: {
		type: String,
		required: true
	},
	isRead: {
		type: Boolean,
		default: false
	},
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const user = await User.findById(this.user);
	const formattedUser = await user?.format();

	const parsedContent = this.content;

	return {
		id: this.id,
		fid: this.fid,
		title: this.title,
		content: this.content,
		parsedContent: parsedContent,
		user: formattedUser,
		link: `/notification/${this.fid}`,
		isRead: Boolean(this.isRead),
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};
	
};

module.exports = mongoose.model('Notification', schema);