const mongoose = require('mongoose');
const TicketCategory = require('./TicketCategory');
const User = require('./User');
const generateId = require('../utils/generateId');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	category: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	status: {
		type: Number,
		default: 0 // 0 = Open, 1 = Resolved, 2 = Closed
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const ticketCategory = await TicketCategory.findById(this.category);
	const formattedTicketCategory = await ticketCategory?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		fid: this.fid,
		category: formattedTicketCategory,
		subcategory: this.subcategory,
		content: this.content,
		parsedContent: parsedContent,
		link: `/ticket/${this.fid}`,
		status: this.status,
		author: formattedAuthor,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	const ticketCategory = await TicketCategory.findById(this.category);
	if (!ticketCategory) {
		return false;
	}

	if (await user.hasAnyRank(ticketCategory.moderationRanks)) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('Ticket', schema);