const mongoose = require('mongoose');
const Appeal = require('./Appeal');
const User = require('./User');

const schema = new mongoose.Schema({
	author: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	appeal: {
		type: String,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const appeal = await Appeal.findById(this.appeal);
	const formattedAppeal = await appeal?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;

	return {
		id: this.id,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		appeal: formattedAppeal,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('AppealReply', schema);