const mongoose = require('mongoose');
const crypto = require('crypto');
const User = require('./User');

const schema = new mongoose.Schema({
	user: {
		type: String,
		required: true
	},
	code: {
		type: String,
		default: () => crypto.randomBytes(64).toString('hex')
	},
	isExpired: {
		type: Boolean,
		default: false
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const user = await User.findById(this.user);
	const formattedUser = await user?.format();

	return {
		id: this.id,
		user: formattedUser,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};
	
};

module.exports = mongoose.model('UserPasswordReset', schema);