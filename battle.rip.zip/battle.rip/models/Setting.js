const mongoose = require('mongoose');

const schema = new mongoose.Schema({
	key: {
		type: String,
		required: true
	},
	value: {
		type: String,
		default: null
	},
},
{
	timestamps: true
});

schema.statics.getSettings = async function() {

	const settings = await this.find();
	
	const settingsObj = {};
	for (const setting of settings) {
		settingsObj[setting.key] = setting.value;
	}

	return settingsObj;

};

module.exports = mongoose.model('Setting', schema);