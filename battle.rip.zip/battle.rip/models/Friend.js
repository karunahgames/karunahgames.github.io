const mongoose = require('mongoose');
const User = require('./User');

const schema = new mongoose.Schema({
	requester: {
		type: String,
		required: true
	},
	recipient: {
		type: String,
		required: true
	},
	status: {
		type: Number,
		default: 0 // 0 = Pending, 1 = Accepted, 2 = Rejected, 3 = Cancelled/Removed
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const requester = await User.findById(this.requester);
	const formattedRequester = await requester?.format();

	const recipient = await User.findById(this.recipient);
	const formattedRecipient = await recipient?.format();

	return {
		id: this.id,
		requester: formattedRequester,
		recipient: formattedRecipient,
		status: this.status,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.statics.getFriends = async function(userId) {

	const friends = await this.find({
		$or: [
			{ requester: userId },
			{ recipient: userId }
		]
	});

	const friendsArr = [];
	for (const friend of friends) {

		if (friend.status !== 1) {
			continue;
		}

		let friendUserId = friend.requester;
		if (friend.requester === userId) {
			friendUserId = friend.recipient;
		}

		const friendUser = await User.findById(friendUserId);
		if (friendUser) {
			friendsArr.push(friendUser);
		}

	}

	return friendsArr;

}

module.exports = mongoose.model('Friend', schema);