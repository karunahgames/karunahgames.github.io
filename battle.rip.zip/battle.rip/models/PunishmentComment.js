const mongoose = require('mongoose');
const User = require('./User');
const formatTime = require('../utils/formatTime');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	content: {
		type: String,
		required: true
	},
	punishment: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(this.content);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		punishment: this.punishment,
		author: formattedAuthor,
		content: this.content,
		parsedContent: parsedContent,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};
	
};

module.exports = mongoose.model('PunishmentComment', schema);