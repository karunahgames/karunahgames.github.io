const mongoose = require('mongoose');
const ForumCategory = require('./ForumCategory');

const schema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	description: {
		type: String,
		default: ''
	},
	slug: {
		type: String,
		required: true
	},
	order: {
		type: Number,
		default: 5
	},
	category: {
		type: String,
		required: true
	},
	redirectUrl: {
		type: String,
		default: null
	},
	isRestricted: {
		type: Boolean,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const forumCategory = await ForumCategory.findById(this.category);
	const formattedForumCategory = await forumCategory?.format();

	return {
		id: this.id,
		name: this.name,
		description: this.description,
		slug: this.slug,
		link: `/forums/${this.slug}`,
		order: this.order,
		category: formattedForumCategory,
		redirectUrl: this.redirectUrl,
		isRestricted: Boolean(this.isRestricted)
	};

};

module.exports = mongoose.model('Forum', schema);