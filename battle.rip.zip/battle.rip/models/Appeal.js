const mongoose = require('mongoose');
const User = require('./User');
const Rank = require('./Rank');
const generateId = require('../utils/generateId');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	type: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	answers: {
		type: Object,
		required: true
	},
	status: {
		type: Number,
		default: 0 // 0 = Open, 1 = Accepted, 2 = Rejected
	},
	isHidden: {
		type: Boolean,
		default: false
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();

	let assigned = '';
	if (this.type === 'mute') {
		assigned = 'Low Staff';
	} else if (this.type === 'ban') {
		assigned = 'Medium Staff';
	} else if (this.type === 'ipban') {
		assigned = 'High Staff';
	} else if (this.type === 'blacklist') {
		assigned = 'Head Staff';
	}

	return {
		id: this.id,
		fid: this.fid,
		type: this.type,
		answers: this.answers,
		link: `/appeal/${this.fid}`,
		status: this.status,
		assigned: assigned,
		author: formattedAuthor,
		isHidden: Boolean(this.isHidden),
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	let minRank = null;
	if (this.type === 'mute') {
		minRank = await Rank.findOne({ name: 'TRIALMOD' });
	} else if (this.type === 'ban') {
		minRank = await Rank.findOne({ name: 'MODPLUS' });
	} else if (this.type === 'ipban') {
		minRank = await Rank.findOne({ name: 'JUNIORADMINISTRATOR' });
	} else if (this.type === 'blacklist') {
		minRank = await Rank.findOne({ name: 'PLATFORMADMINISTRATOR' });
	}

	const userRanks = await user.getRanks();
	if (minRank && userRanks.some((r) => r.order >= minRank.order)) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('Appeal', schema);