const mongoose = require('mongoose');
const User = require('./User');
const formatTime = require('../utils/formatTime');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	content: {
		type: String,
		required: true
	},
	user: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	editedAt: {
		type: Date,
		default: null
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const user = await User.findById(this.user);
	const formattedUser = await user?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(this.content);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		user: formattedUser,
		author: formattedAuthor,
		content: this.content,
		parsedContent: parsedContent,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt),
		editedAt: formatTime(this.editedAt)
	};
	
};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('ProfilePost', schema);