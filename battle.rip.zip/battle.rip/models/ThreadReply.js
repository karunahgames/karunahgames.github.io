const mongoose = require('mongoose');
const Thread = require('./Thread');
const User = require('./User');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');
const formatTime = require('../utils/formatTime');

const schema = new mongoose.Schema({
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	thread: {
		type: String,
		required: true
	},
	upvotes: {
		type: Array,
		default: []
	},
	editedAt: {
		type: Date,
		default: null
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const thread = await Thread.findById(this.thread);
	const formattedThread = await thread?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		thread: formattedThread,
		link: `/forums/${thread?.id}/replies/${this.id}`,
		isDeleted: Boolean(this.deletedAt),
		upvotes: this.upvotes,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt),
		editedAt: formatTime(this.editedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}
	
	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('ThreadReply', schema);