const mongoose = require('mongoose');
const Wiki = require('./Wiki');
const User = require('./User');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	wiki: {
		type: String,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const wiki = await Wiki.findById(this.wiki);
	const formattedWiki = await wiki?.format();

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		title: this.title,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		wiki: formattedWiki,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}
	
	if (user.id === this.author) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('WikiPost', schema);