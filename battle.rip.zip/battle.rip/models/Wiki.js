const mongoose = require('mongoose');
const Rank = require('./Rank');
const User = require('./User');
const encodeString = require('../utils/encodeString');
const parseMarkdown = require('../utils/parseMarkdown');

const schema = new mongoose.Schema({
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	author: {
		type: String,
		required: true
	},
	order: {
		type: Number,
		default: 5
	},
	slug: {
		type: String,
		required: true
	},
	accessRanks: {
		type: Array,
		default: []
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const accessRanks = [];
	for (const rankId of this.accessRanks) {
		const rank = await Rank.findById(rankId);
		if (rank) {
			const formattedRank = await rank.format();
			accessRanks.push(formattedRank);
		}
	}

	const author = await User.findById(this.author);
	const formattedAuthor = await author?.format();
	
	let parsedContent = this.content;
	parsedContent = await encodeString(parsedContent);
	parsedContent = await parseColors(parsedContent);
	parsedContent = await parseMarkdown(parsedContent, true);

	return {
		id: this.id,
		title: this.title,
		content: this.content,
		parsedContent: parsedContent,
		author: formattedAuthor,
		order: this.order,
		slug: this.slug,
		accessRanks: accessRanks,
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	return false;

};

const parseColors = (string) => {

	let parsedString = string;

	let regex = /(?:{)([^}]*)(?:})/g;
	while ((result = regex.exec(parsedString)) !== null) {

		const token = result[0];
		const tokenArr = token.slice(1, -1).split(':');

		if (tokenArr[0] === 'color') {
			if (tokenArr[1] === 'end') {
				parsedString = parsedString.replace(result[0], `</span>`);
			} else {
				parsedString = parsedString.replace(result[0], `<span style="color: ${tokenArr[1]};">`);
			}
		}

		if (tokenArr[0] === 'align') {
			if (tokenArr[1] === 'end') {
				parsedString = parsedString.replace(result[0], `</div>`);
			} else {
				parsedString = parsedString.replace(result[0], `<div style="text-align: ${tokenArr[1]};">`);
			}
		}

	}

	return parsedString;

}

module.exports = mongoose.model('Wiki', schema);