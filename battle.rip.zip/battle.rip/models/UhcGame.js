const mongoose = require('mongoose');
const User = require('./User');
const generateId = require('../utils/generateId');

const schema = new mongoose.Schema({
	fid: {
		type: String,
		default: () => generateId()
	},
	server: {
		type: String,
		default: null
	},
	mode: {
		type: String,
		default: null
	},
	host: {
		type: String,
		required: true
	},
	scenarios: {
		type: String,
		default: ''
	},
	options: {
		type: Object,
		default: {}
	},
	potions: {
		type: Object,
		default: {}
	},
	timings: {
		type: Object,
		default: {}
	},
	status: {
		type: Number,
		default: 0 // 0 = Pending, 1 = Accepted, 2 = Rejected
	},
	openingAt: {
		type: Date,
		required: true
	}
},
{
	timestamps: true
});

schema.methods.format = async function() {

	const host = await User.findById(this.host);
	const formattedHost = await host?.format();

	const region = this.server.split('-')[0];

	let serverIp = 'battle.rip';
	if (region === 'eu') {
		serverIp = 'eu.battle.rip'
	} else if (region === 'na') {
		serverIp = 'na.battle.rip'
	} else if (region === 'sa') {
		serverIp = 'sa.battle.rip'
	}

	let teamSize = 'FFA';
	if (this.mode.toLowerCase().startsWith('to')) {
		teamSize = parseInt(this.mode.toLowerCase().replace('to', ''));
	}

	const curentTime = new Date();
	const openingAt = new Date(this.openingAt);

	let isDone = false;
	if (curentTime > openingAt) {
		isDone = true;
	}

	return {
		id: this.id,
		fid: this.fid,
		server: this.server.toUpperCase(),
		serverIp: serverIp,
		region: region.toUpperCase(),
		mode: this.mode.toUpperCase(),
		teamSize: teamSize,
		host: formattedHost,
		scenarios: this.scenarios.split(', ').filter(Boolean),
		options: this.options,
		potions: this.potions,
		timings: this.timings,
		status: this.status,
		isDone: Boolean(isDone),
		openingAt: formatTime(this.openingAt),
		createdAt: formatTime(this.createdAt),
		updatedAt: formatTime(this.updatedAt)
	};

};

schema.methods.isManageableBy = async function(user) {

	if (!user) {
		return false;
	}

	if (await user.hasAdminPermission()) {
		return true;
	}

	return false;

};

module.exports = mongoose.model('UhcGame', schema);