const marked = require('marked');

module.exports = parseMarkdown = (string, inline = true) => {

	return new Promise(async (resolve, reject) => {

		let parsedString = '';

		if (inline) {
			parsedString = await marked.parseInline(string).split("\r\n").join('<br>');
		} else {
			parsedString = await marked(string).split("\r\n").join('<br>');
		}
		
		return resolve(parsedString);

	});
	
}