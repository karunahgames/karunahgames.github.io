const nodemailer = require('nodemailer');
const config = require('../config.json');

module.exports = sendMail = ({ email, subject, body }) => {

	const emailConfig = config.email;

	return new Promise((resolve, reject) => {

		const transporter = nodemailer.createTransport({
			name: emailConfig.name,
			host: emailConfig.host,
			port: emailConfig.port,
			secure: emailConfig.secure,
			auth: {
				user: emailConfig.username,
				pass: emailConfig.password,
			},
			tls: {
				rejectUnauthorized: false,
			},
		});

		const mailOptions = {
			from: {
				name: emailConfig.name,
				address: emailConfig.address
			},
			to: email,
			subject: subject,
			html: body
		};

		transporter.sendMail(mailOptions)
			.then(() => {
				resolve(true);
			})
			.catch((err) => {
				console.log(err);
				resolve(false);
			});

	});
	
}