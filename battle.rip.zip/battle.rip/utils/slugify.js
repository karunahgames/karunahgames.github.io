module.exports = slugify = (string) => {

	let slug = string.toLowerCase();
	slug = slug.replace(/[^\w ]+/g, '')
	slug = slug.replace(/ +/g, '-');

	return slug;

}