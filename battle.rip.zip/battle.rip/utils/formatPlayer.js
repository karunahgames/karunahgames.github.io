const getPlayerInfo = require('./getPlayerInfo');
const getPlayerRanks = require('./getPlayerRanks');

module.exports = formatPlayer = (player) => {

	return new Promise(async (resolve, reject) => {

		let playerUuid = player?.uuid || 'null';
		let playerName = player?.name || 'Player';

		if (player?.uuid && !player?.name) {
			const playerInfo = await getPlayerInfo(player.uuid, 'uuid');
			if (playerInfo) {
				playerName = playerInfo.name;
			}
		}

		const playerRanks = await getPlayerRanks(playerUuid) ?? [];
		const formattedPlayerRanks = await Promise.all(playerRanks.map((rank) => rank.format()));
		
		let playerLink = '#';
		if (playerUuid && playerName) {
			playerLink = `/profile/${playerName}`
		}

		const isPlayerStaff = playerRanks.some((rank) => rank.isStaff);

		let playerHtml = `<a href="${playerLink}">${playerName}</a>`;
		let playerAvatarHtml = `<img class="avatar" src="https://visage.surgeplay.com/face/${playerUuid}">`;
		if (playerRanks.length > 0) {
			playerHtml = `<a href="${playerLink}" style="color: ${playerRanks[0].color};">${playerName}</a>`;
			playerAvatarHtml = `<img class="avatar" src="https://visage.surgeplay.com/face/${playerUuid}" style="--border-color: ${playerRanks[0].color};">`;
			if (isPlayerStaff) {
				playerHtml = `<a href="${playerLink}" style="color: ${playerRanks[0].color};"><strong>${playerName}</strong></a>`;
			}
		}

		const formattedPlayer = {
			uuid: playerUuid,
			name: playerName,
			link: playerLink,
			color: playerRanks.length > 0 ? playerRanks[0].color : null,
			html: playerHtml,
			ranks: formattedPlayerRanks,
			rank: formattedPlayerRanks[0],
			avatar: {
				face: `https://visage.surgeplay.com/face/${playerUuid}`,
				bust: `https://visage.surgeplay.com/bust/${playerUuid}`,
				full: `https://visage.surgeplay.com/full/${playerUuid}`,
				body: `https://crafatar.com/renders/body/${playerUuid}`,
				html: playerAvatarHtml
			}
		};
		
		return resolve(formattedPlayer);

	});

}