const getDatabaseData = require('./getDatabaseData');

module.exports = getMatch = () => {

	return new Promise(async (resolve, reject) => {

		const matchesData = await getDatabaseData('uhc', 'matchRecord');
		if (!matchesData) {
			return resolve(null);
		}

		return resolve(matchesData);
		
	});

}