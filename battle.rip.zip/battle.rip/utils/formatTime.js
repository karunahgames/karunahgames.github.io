const moment = require('moment');

module.exports = formatTime = (time) => {

	if (!time) {
		return null;
	}

	const momentTime = moment(time);

	const formattedTime = {
		short: momentTime.format('MMMM DD YYYY'),
		long: momentTime.format('MMMM Do YYYY, h:mm:ss a'),
		relative: momentTime.fromNow(),
		timestamp: momentTime.valueOf(),
		time: momentTime.format(),
	};

	formattedTime.html = `<span title="${formattedTime.long}">${formattedTime.relative}</span>`
	
	return formattedTime;

}