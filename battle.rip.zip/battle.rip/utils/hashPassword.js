const bcrypt = require('bcrypt');

module.exports = hashPassword = (password) => {

	return new Promise(async (resolve, reject) => {

		const salt = await bcrypt.genSalt(10);
		const hashedPassword = await bcrypt.hash(password, salt);
	
		return resolve(hashedPassword);

	});

}