const formatPlayer = require('./formatPlayer');
const formatTime = require('./formatTime');
const getPlayer = require('./getPlayer');

module.exports = formatPunishment = async (punishment) => {

	const player = await getPlayer(punishment.uuid);
	const formattedPlayer = await formatPlayer(player);

	const punisher = await getPlayer(punishment.added_by);
	const formattedPunisher = await formatPlayer(punisher);

	let endsAt = -1;
	if (!punishment.permanent) {
		endsAt = punishment.added_at + punishment.duration;
	}

	const formattedPunishment = {
		id: punishment.id,
		type: punishment.type.toUpperCase(),
		player: formattedPlayer,
		server: punishment.serverid,
		duration: punishment.duration,
		reason: punishment.reason,
		punisher: formattedPunisher,
		addedAt: formatTime(punishment.added_at),
		endsAt: formatTime(endsAt),
		isSilent:  Boolean(punishment.silent),
		isPermanent: Boolean(punishment.permanent),
		isRemoved:  Boolean(punishment.removed)
	};

	return formattedPunishment;
	
}
