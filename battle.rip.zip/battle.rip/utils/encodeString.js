const htmlEntities = require('html-entities');

module.exports = parseVariables = (string) => {

	return new Promise(async (resolve, reject) => {

		const parsedString = htmlEntities.encode(string);
		return resolve(parsedString);

	});
	
}