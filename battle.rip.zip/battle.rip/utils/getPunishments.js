const getDatabaseData = require('./getDatabaseData');

module.exports = getPunishments = () => {

	return new Promise(async (resolve, reject) => {

		const punishmentsData = await getDatabaseData('core', 'punishments');

		const punishments = [];
		for (const punishment of punishmentsData) {

			let isPermanent = false;
			if (punishment.duration == 1648226673468) {
				isPermanent = true;
			}

			let isRemoved = false;
			if (punishment.duration != 1648226673468) {
				const expirationDate = punishment.added_at + punishment.duration;
				if (expirationDate < Date.now()) {
					isRemoved = true;
				}
			}

			punishments.push({
				...punishment,
				permanent: isPermanent,
				removed: isRemoved,
			});

		}

		return resolve(punishments);
		
	});

}