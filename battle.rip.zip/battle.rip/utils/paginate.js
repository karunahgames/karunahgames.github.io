module.exports = paginate = (items, page = 1, limit = 10, link = '?page={x}') => {

	const offset = limit * (page - 1);
	const totalPages = Math.ceil(items.length / limit) || 1;
	const paginatedItems = items.slice(offset, limit * page);

	const pagination = {
		currentPage: page,
		previousPage: page - 1 ? page - 1 : null,
		nextPage: (totalPages > page) ? page + 1 : null,
		total: items.length,
		totalPages: totalPages,
		items: paginatedItems,
		nav: []
	};

	const paginationNav = [];
	for (let i = 1; i <= pagination.totalPages; i++) {
		paginationNav.push({
			name: i,
			active: pagination.currentPage === i,
			link: link.replace('{x}', i)
		});
	}

	pagination.nav.push({
		name: '<',
		active: false,
		link: (pagination.previousPage ? link.replace('{x}', pagination.previousPage) : '#')
	});

	const truncatedPagination = truncatePagination(paginationNav);
	pagination.nav.push(...truncatedPagination);

	pagination.nav.push({
		name: '>',
		active: false,
		link: (pagination.nextPage ? link.replace('{x}', pagination.nextPage) : '#')
	});

	return pagination;
	
}

function truncatePagination(pagination) {

	let totalIndexes = pagination.length - 1;
	let activeIndex = pagination.findIndex((page) => page.active);

	if (totalIndexes > 4 && activeIndex > 3) {
		if (totalIndexes - activeIndex > 3) {
			pagination.splice(1, activeIndex - 2, {
				name: '...',
				active: false,
				link: '#'
			});
		} else {
			pagination.splice(1, activeIndex - 2, {
				name: '...',
				active: false,
				link: '#'
			});
		}
	}

	totalIndexes = pagination.length - 1;
	activeIndex = pagination.findIndex((page) => page.active);

	if (totalIndexes > 4 && totalIndexes - activeIndex > 3) {
		if (activeIndex > 1) {
			pagination.splice(activeIndex + 2, totalIndexes - activeIndex - 2, {
				name: '...',
				active: false,
				link: '#'
			});
		} else {
			pagination.splice(activeIndex + 3, totalIndexes - activeIndex - 3, {
				name: '...',
				active: false,
				link: '#'
			});
		}
	}

	return pagination;

}