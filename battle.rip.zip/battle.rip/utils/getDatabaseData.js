const getDatabase = require('./getDatabase');

module.exports = getDatabaseData = (databaseName, collection, query = { }, sort = { }) => {

	return new Promise(async (resolve, reject) => {

		const database = await getDatabase(databaseName);
		if (!database) {
			return resolve(null);
		}
		
		const data = await database.collection(collection).find(query).sort(sort).toArray();
		return resolve(data);

	});

}