const mongo = require('mongodb');
const config = require('../config.json');

const databasesCache = { };

module.exports = getDatabase = (dbName) => {

	return new Promise(async (resolve, reject) => {

		const databasesConfig = config.databases;
		
		if (!databasesConfig[dbName]) {
			return resolve(null);
		}

		if (!(dbName in databasesCache)) {
			const client = new mongo.MongoClient(databasesConfig[dbName], { useNewUrlParser: true, useUnifiedTopology: true });
			await client.connect();
			databasesCache[dbName] = client.db();
		}

		return resolve(databasesCache[dbName]);

	});

}