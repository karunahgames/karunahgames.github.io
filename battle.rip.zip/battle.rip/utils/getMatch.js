const getDatabaseData = require('./getDatabaseData');

module.exports = getMatch = (id) => {

	return new Promise(async (resolve, reject) => {

		const matchesData = await getDatabaseData('uhc', 'matchRecord', { matchId: `#${id}` });
		if (!matchesData) {
			return resolve(null);
		}

		const matchData = matchesData[0];
		if (!matchData) {
			return resolve(null);
		}

		return resolve(matchData);
		
	});

}