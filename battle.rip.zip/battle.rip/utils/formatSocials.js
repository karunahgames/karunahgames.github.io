module.exports = formatSocials = (rawSocials) => {

	const socials = [];

	if (!rawSocials) {
		return socials;
	}

	for (const [key, value] of Object.entries(rawSocials)) {
		if (key in links && value) {
			socials.push({
				name: key,
				title: key.capitalize(),
				link: links[key].replace('{x}', value)
			});
		}
	}

	return socials;
	
}

const links = {
	youtube: 'https://youtube.com/{x}',
	twitter: 'https://twitter.com/{x}',
	twitch: 'https://twitch.tv/',
	steam: 'https://steamcommunity.com/id/{x}',
	reddit: 'https://reddit.com/u/{x}',
	github: 'https://github.com/{x}',
	telegram: 'https://telegram.me/{x}',
	discord: 'discord:{x}',
};
