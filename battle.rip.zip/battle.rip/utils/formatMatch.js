module.exports = formatMatch = async (match) => {

	const killInformation = match.killInformation;

	const formattedMatch = {
		id: match.matchId.replace('#', ''),
		type: match.type.toUpperCase(),
		fill: match.fill,
		winner: match.winner,
		timeElpased: match.timeElpased,
		killInformation: killInformation
	};

	return formattedMatch;
	
}
