const getDatabaseData = require('./getDatabaseData');

module.exports = getPlayer = (uuid) => {

	return new Promise(async (resolve, reject) => {

		const playersData = await getDatabaseData('core', 'players', { uuid });
		if (!playersData) {
			return resolve(null);
		}

		const playerData = playersData[0];
		if (!playerData) {
			return resolve(null);
		}

		const player = {
			uuid: playerData.uuid,
			firstJoin: null,
			lastSeen: playerData.lastSeen
		};

		return resolve(player);

	});

}