module.exports = getRanks = (rankName = null) => {

	return new Promise(async (resolve, reject) => {
		
		const ranks = [];
		for (const rank of ranksData) {
			if (!rankName || rankName === rank) {
				ranks.push({
					name: rank
				});
			}
		}

		return resolve(ranks);

	});

}

const ranksData = [
	'OWNER',
	'HEADADMINISTRATOR',
	'HEADDEVELOPER',
	'SENIORADMINISTRATOR',
	'PLATFORMADMINISTRATOR',
	'SENIORADMINISTRATOR',
	'ADMINISTRATOR',
	'JUNIORADMINISTRATOR',
	'DEVELOPER',
	'SENIORMOD',
	'MODPLUS',
	'MOD',
	'TRIALMOD',
	'GAMEDESIGNER',
	'PLAYERCOUNCIL',
	'TRANSLATOR',
	'BUILDER',
	'PARTNER',
	'FAMOUSPLUS',
	'FAMOUS',
	'YOUTUBER',
	'STREAMER',
	'MINI_YT',
	'PARTNER',
	'AFFILIATED',
	'FAMOUS+',
	'FAMOUS',
	'STREAMER',
	'YOUTUBE',
	'MINIYOUTUBE',
	'BATTLE',
	'KINGPLUS',
	'KING',
	'MASTER',
	'HERO',
	'SOLDIER',
	'KNIGHT',
	'WARRIOR',
	'RETIRED',
	'VERIFIED',
	'DEFAULT'
];