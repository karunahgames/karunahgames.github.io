const getDatabaseData = require('./getDatabaseData');

module.exports = getPlayers = () => {

	return new Promise(async (resolve, reject) => {
		
		const playersData = await getDatabaseData('core', 'players');
		if (!playersData) {
			return resolve(null);
		}

		const players = [];
		for (const playerData of playersData) {
			players.push({
				uuid: playerData.uuid,
				firstJoin: null,
				lastSeen: playerData.lastSeen
			});
		}

		return resolve(players);

	});

}