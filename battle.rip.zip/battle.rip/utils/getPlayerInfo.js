const axios = require('axios');

let cache = { };

module.exports = getPlayerInfo = (query, queryType = 'username') => {

	return new Promise(async (resolve, reject) => {

		let _query = query;
		if (queryType === 'uuid') {
			_query = query.replace(/[^a-z0-9+]+/gi, '');
		}

		const cacheDuration = 6 * 60 * 60 * 1000; // 6 hours
		const currentTime = Date.now();

		if (query in cache && cache[query].time + cacheDuration > currentTime) {
			const playerInfo = cache[query].data;
			return resolve(playerInfo);
		}

		let response = null;
		try {
			if (queryType === 'uuid') {
				response = await axios.get(`https://sessionserver.mojang.com/session/minecraft/profile/${_query}`);
			} else {
				response = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${_query}`);
			}
		} catch (err) { }

		if (!response) {
			return resolve(null);
		}
	
		const responseData = response?.data;
		if (!responseData) {
			return resolve(null);
		}

		const playerInfo = {
			uuid: formatUuid(responseData.id),
			name: responseData.name
		};

		cache[query] = {
			time: currentTime,
			data: playerInfo
		};

		return resolve(playerInfo);

	});

}

function formatUuid(uuid) {

	const formattedUuid = uuid.substr(0, 8) + '-' + uuid.substr(8, 4) + '-' + uuid.substr(12, 4) + '-' + uuid.substr(16, 4) + '-' + uuid.substr(20);
	return formattedUuid;

}