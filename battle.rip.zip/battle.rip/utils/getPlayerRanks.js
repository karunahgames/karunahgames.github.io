const Rank = require('../models/Rank');

module.exports = getPlayerRanks = (uuid) => {

	return new Promise(async (resolve, reject) => {

		const playersData = await getDatabaseData('core', 'players', { uuid });

		const player = playersData[0];
		if (!player) {
			return resolve([]);
		}

		const playerGrantsData = JSON.parse(player.grants);
		
		const playerRanks = [];
		for (const grant of playerGrantsData) {

			if (grant.removed) {
				continue;
			}

			const expirationDate = grant.addedAt + grant.duration;
			if (grant.duration !== 2147483647 && expirationDate < Date.now()) {
				continue;
			}

			const rank = await Rank.findOne({ name: grant.rank });
			if (rank) {
				playerRanks.push(rank);
			}

		}

		playerRanks.sort((a, b) => {
			return a.order - b.order
		});

		const filteredPlayerRanks = playerRanks.filter((v, i, a) => a.findIndex((t) => (t.name === v.name)) === i);

		return resolve(filteredPlayerRanks);
		
	});

}