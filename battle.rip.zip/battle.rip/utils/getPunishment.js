const getDatabaseData = require('./getDatabaseData');

module.exports = getPunishment = (id) => {

	return new Promise(async (resolve, reject) => {

		const punishmentsData = await getDatabaseData('core', 'punishments', { id });
		if (!punishmentsData) {
			return resolve(null);
		}

		const punishmentData = punishmentsData[0];
		if (!punishmentData) {
			return resolve(null);
		}

		let isPermanent = false;
		if (punishmentData.duration == 1648226673468) {
			isPermanent = true;
		}

		let isRemoved = false;
		if (punishmentData.duration != 1648226673468) {
			const expirationDate = punishmentData.added_at + punishmentData.duration;
			if (expirationDate < Date.now()) {
				isRemoved = true;
			}
		}

		const punishment = {
			...punishmentData,
			permanent: isPermanent,
			removed: isRemoved,
		};

		return resolve(punishment);
		
	});

}