const Twit = require('twit');
const fetch = require('node-fetch');
const fs = require('fs');
const UhcGame = require('../models/UhcGame');
const uhcConfig = require('../config.uhc.json');

module.exports = async (app) => {

	if (!uhcConfig.serviceEnabled) {
		return;
	}

	(async () => {

		const THIRTY_SECONDS = 1000 * 30;
		const FORTY_FIVE_MINUTES = 1000 * 60 * 45;
		const FIFTEEN_MINUTES = 1000 * 60 * 15;
		const INTERVAL = THIRTY_SECONDS;

		setInterval(async () => {

			const uhcGames = await UhcGame.find({ status: 1 });
			for (const game of uhcGames) {

				const currentTime = new Date();
				const openingAt = new Date(game.openingAt);
				const openingAtInUtc = new Date(openingAt.toUTCString().slice(0, 25));
				const openingAtInEst = new Date(openingAt.toLocaleString('en-US', { timeZone: 'America/New_York' }));
				const timeLeft = parseInt(openingAt.getTime() - currentTime.getTime());

				let minutesLeft = 0;
				if (timeLeft >= FORTY_FIVE_MINUTES - (INTERVAL / 2) && timeLeft <= FORTY_FIVE_MINUTES + (INTERVAL / 2)) {
					minutesLeft = 45;
				} else if (timeLeft >= FIFTEEN_MINUTES - (INTERVAL / 2) && timeLeft <= FIFTEEN_MINUTES + (INTERVAL / 2)) {
					minutesLeft = 15;
				}

				if (minutesLeft) {
					const region = game.server.split('-')[0].toLowerCase();
					const serverIp = `${region}.battle.rip`;

					(async () => {

						const opensText = `${zeroPad(openingAtInUtc.getHours(), 2)}:${zeroPad(openingAtInUtc.getMinutes(), 2)} UTC`;

						const message = `🚀 Battle UHC | ${region.toUpperCase()}`
							+ '\n'
							+ '\n' + `🎮 ${game.mode.toUpperCase()} | ${game.scenarios}`
							+ '\n' + `🔥 Nether: ${game.options.nether ? 'Enabled' : 'Disabled'}`
							+ '\n' + `🕒 Opens: ${opensText} (in ${minutesLeft} minutes) | <http://time.is/UTC>`
							+ '\n'
							+ '\n' + `🚩 IP: ${serverIp} | /server ${game.server}`;

						for (const [name, discord] of Object.entries(uhcConfig.gameFeedDiscord)) {
							try {
								await fetch(discord.webhookUrl, {
									method: 'POST',
									headers: { 'content-type': 'application/json' },
									body: JSON.stringify({
										'content': `<#${discord.channelId}>`
											+ '\n' + message
											+ '\n'
											+ '\n' + `<@&${discord.notifyRoleId}>`
									})
								});
							} catch (err) {
								console.log(err);
							}
						}

					})();

					(async () => {

						let opensText = `${zeroPad(openingAtInUtc.getHours(), 2)}:${zeroPad(openingAtInUtc.getMinutes(), 2)} UTC`;
						if (region === 'na') {
							opensText = `${zeroPad(openingAtInEst.getHours(), 2)}:${zeroPad(openingAtInEst.getMinutes(), 2)} EST`;
						}
	
						const message = `🚀 Battle UHC | ${region.toUpperCase()}`
							+ '\n'
							+ '\n' + `🎮 ${game.mode.toUpperCase()} | ${game.scenarios}`
							+ '\n' + `🔥 Nether: ${game.options.nether ? 'Enabled' : 'Disabled'}`
							+ '\n' + `🕒 Opens: ${opensText} (in ${minutesLeft} minutes) ${minutesLeft == 15 ? ' | http://time.is/EST' : ''}`
							+ '\n'
							+ '\n' + `🚩 IP: ${serverIp} | /server ${game.server}`;
	
						for (const [name, twitter] of Object.entries(uhcConfig.gameFeedTwitter)) {
							try {
								const T = new Twit({
									consumer_key: twitter.apiKey,
									consumer_secret: twitter.apiKeySecret,
									access_token: twitter.accessToken,
									access_token_secret: twitter.accessTokenSecret
								});
								T.post('statuses/update', { status: message }, function(err, data, response) {
									if (err) {
										console.log(err);
									}
								});
							} catch (err) {
								console.log(err);
							}
						}
					
					})();
				}
			}
		}, INTERVAL);

	})();

	(async () => {

		const FIVE_MINUTES = 1000 * 60 * 5;
		const INTERVAL = FIVE_MINUTES;

		setInterval(async () => {

			const currentTime = new Date();
			const upcomingGames = await UhcGame.find({ status: 1, openingAt: { $gte: currentTime } }).sort({ openingAt: 1 });

			let message = '» _currently no games are planned_\n';

			if (upcomingGames && upcomingGames.length > 0) {
				message = '';
				for (const [i, game] of upcomingGames.entries()) {
					if (i === 4) {
						message += `_+${upcomingGames.length - 4} more games planned! Check out https://battle.rip/matches_\n`;
						break;
					} else {

						const openingAt = new Date(game.openingAt);
						const openingAtInUtc = new Date(openingAt.toUTCString().slice(0, 25));
						const openingAtInEst = new Date(openingAt.toLocaleString('en-US', { timeZone: 'America/New_York' }));

						const region = game.server.split('-')[0];

						let flagEmoji = ':question:';
						if (region === 'eu') {
							flagEmoji = ':flag_eu:';
						} else if (region === 'na') {
							flagEmoji = ':flag_us:';
						}

						message += `» ${flagEmoji} ${game.mode.toUpperCase()} | ${game.scenarios}` 
							+ ` - **${zeroPad(openingAtInUtc.getHours(), 2)}:${zeroPad(openingAtInUtc.getMinutes(), 2)} UTC**`
							+ ` / **${zeroPad(openingAtInEst.getHours(), 2)}:${zeroPad(openingAtInEst.getMinutes(), 2)} EST**\n`;
					}	
				}
			}

			for (const [name, discord] of Object.entries(uhcConfig.matchTableDiscord)) {

				let messageTitle = '<:battle:756328652605751327> **Battle Network | Match Table**';
				if (name === 'uhcHub') {
					messageTitle = '<:beacon:928502223967772672> **UHCHub | Match Table**';
				}

				try {
					if (!discord.messageId) {
						const response = await fetch(`${discord.webhookUrl}?wait=true`, {
							method: 'POST',
							headers: { 'content-type': 'application/json' },
							body: JSON.stringify({ content: '-' })
						});
						const data = await response.json();
						uhcConfig.matchTableDiscord[name].messageId = data.id;
						fs.writeFileSync('././config.uhc.json', JSON.stringify(uhcConfig, null, 4));
					}
					await fetch(`${discord.webhookUrl}/messages/${discord.messageId}`, {
						method: 'PATCH',
						headers: { 'content-type': 'application/json' },
						body: JSON.stringify({
							content: messageTitle
							+ '\n' + '\n' + message
							+ '\n' + '_battle.rip_ | _eu.battle.rip_ | _na.battle.rip_'
						})
					});
				} catch (err) {
					console.log(err);
				}
			}
		}, INTERVAL);

	})();

}

const zeroPad = (num, places) => {
	const zero = places - num.toString().length + 1;
	return Array(+(zero > 0 && zero)).join('0') + num;
}